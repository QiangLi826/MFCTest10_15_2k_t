//  DllLoader.cpp: CDllLoader class.
//
//   Version 3.0.0.0
//
//   Copyright 2010
//
//   Sebastian Lueth
//   MICRO-EPSILON Optronic GmbH
//   Lessingstrasse 14
//   01465 Dresden OT Langebrueck
//   Germany

//   DRA: adjusted for to work with char arrays
//   We should search for a flexible, offical solution to this issue

#include "DllLoader.h"
#include "stdafx.h"

// <summary>
// constructor of the DllLoader class
// </summary>
// <param name="char* DLLName">name of the dll</param>
// <returns></returns>

CDllLoader::CDllLoader(const char *DLLName, bool *pLoadError /*=nullptr*/)
{
    // init some variables
    m_hDLL = nullptr;

    m_DLLName = DLLName;

    // load the dll
    Load(DLLName, pLoadError);
}


void CDllLoader::updateFileVersion(const TCHAR *pszFilePath )
{
    DWORD               dwSize              = 0;
    BYTE                *pbVersionInfo      = NULL;
    VS_FIXEDFILEINFO    *pFileInfo          = NULL;
    UINT                puLenFileInfo       = 0;

    // Get the version information for the file requested
    dwSize = GetFileVersionInfoSize(pszFilePath, NULL);
    if ( dwSize == 0 ) {
        return ;
    }

    pbVersionInfo = new BYTE[ dwSize ];

    if ( !GetFileVersionInfo(pszFilePath, 0, dwSize, pbVersionInfo)) {
        return ;
    }

    if ( !VerQueryValue(pbVersionInfo, TEXT("\\"), (LPVOID*) &pFileInfo, &puLenFileInfo)) {
        return ;
    }

    std::string file_version;
    file_version.append(std::to_string((pFileInfo->dwFileVersionMS >> 16 ) & 0xffff) + ".");
    file_version.append(std::to_string((pFileInfo->dwFileVersionMS) & 0xffff)  + ".");
    file_version.append(std::to_string((pFileInfo->dwFileVersionLS >>  16 ) & 0xffff)  + ".");
    file_version.append(std::to_string((pFileInfo->dwFileVersionLS) & 0xffff));
    m_file_version = file_version;
}



// <summary>
// destructor of the DllLoader class
// </summary>

CDllLoader::~CDllLoader()
{
    // unload the dll
    Unload();
}

// <summary>
// reloads the dll
// </summary>

void CDllLoader::Reload(bool *pLoadError /*=nullptr*/)
{
    // unload the dll
    Unload();
    // load the dll
    Load(m_DLLName.c_str(), pLoadError);
}

// <summary>
// loads the dll
// </summary>
// <param name="char* Dll">name of the dll</param>

void CDllLoader::Load(const char *Dll, bool *pLoadError /*=nullptr*/)
{
    // load the dll
    m_hDLL = LoadLibrary(convertCharArrayToLPCWSTR(Dll));

    updateFileVersion(convertCharArrayToLPCWSTR(Dll));

    // if the dll-load fails handle the error
    if (!m_hDLL && !pLoadError)
        HandleFatalError(Dll);
    else if (!m_hDLL)
        *pLoadError = true;
}

// <summary>
// unloads the dll and frees the handle
// </summary>

void CDllLoader::Unload()
{
    if (m_hDLL) {
        // if there is a dll free it
        FreeLibrary(m_hDLL);
        m_hDLL = nullptr;
    }
}

// <summary>
// gets a pointer to the requestet function
// </summary>
// <param name="char* FuncName">name of the requested function</param>
// <returns>pointer to the requested function</returns>

FARPROC CDllLoader::GetFunction(const char *FuncName)
{
    if (m_hDLL) {
        FARPROC FuncAdr = GetProcAddress(m_hDLL, FuncName);
        if (FuncAdr == nullptr) {
            std::string strTemp = FuncName;
            strTemp.insert(strTemp.begin(), '_');
            return GetProcAddress(m_hDLL, strTemp.c_str());
        } else
            return FuncAdr;
    } else
        return nullptr;
}

const char *  CDllLoader::getFileVersion()
{
    return m_file_version.c_str();
}

// <summary>
// handels fatal errors and aborts the application
// </summary>
// <param name="char* Dll">name of the dll</param>

void CDllLoader::HandleFatalError(const char *Dll)
{
    // create a buffer for the error-message
    LPVOID lpMsgBuf;
    // create the message text
    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, nullptr,
                  GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), reinterpret_cast<LPTSTR>(&lpMsgBuf), 0, nullptr);
    // copy the error-message in a string
    std::string Text(static_cast<char *>(lpMsgBuf));
    // free's the error-message-buffer
    LocalFree(lpMsgBuf);
    // add the dll-name to the error-string
    Text += Dll;
    // exit the application with a error-messagebox
    FatalAppExit(0, convertCharArrayToLPCWSTR(Text.c_str()));
}

wchar_t *CDllLoader::convertCharArrayToLPCWSTR(const char *charArray)
{
    wchar_t *wString = new wchar_t[4096];
    MultiByteToWideChar(CP_ACP, 0, charArray, -1, wString, 4096);
    return wString;
}
