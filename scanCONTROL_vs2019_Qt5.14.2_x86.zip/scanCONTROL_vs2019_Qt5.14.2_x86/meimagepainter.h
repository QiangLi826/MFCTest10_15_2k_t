/*
 * scanCONTROL Developer Tool - GUI application for LLT.dll and linLLT
 *
 * MIT License
 *
 * Copyright © 2017-2019 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *

 */

#ifndef MEIMAGEPROVIDER_H
#define MEIMAGEPROVIDER_H

#include <QtCore/QMutex>
#include <QtGui/QPainter>
#include <QtQuick/QQuickPaintedItem>

/**
* @brief Image painter class for QtQuick
*
* @details Implements an image painter environment tuned for LLT container and
* video images. Images should be in 8 bit grayscale format.
*
* @author Daniel Rauch, Micro-Epsilon Messtechnik GmbH & Co. KG
* @date 2018-01-03 ‏‎08:41:21 +0100 (Wed, 03 Jan 2018) $
*
*/

class MEImagePainter : public QQuickPaintedItem
{
    Q_OBJECT

    Q_PROPERTY(QImage image MEMBER m_image WRITE setImage)
    Q_PROPERTY(qint32 expected_width MEMBER m_expected_width WRITE setExpectedWidth)
    Q_PROPERTY(qint32 expected_height MEMBER m_expected_height WRITE setExpectedHeight)

  public:
    /**
    * @brief The constructor.
    */
    MEImagePainter()
    {
        setMipmap(true);
        setAntialiasing(true);

        // massive performance improvements compared to QQuickPaintedItem::Image
        setRenderTarget(QQuickPaintedItem::FramebufferObject);
        // enable quicker rescaling | deactivate if RAM is limited
        setPerformanceHint(QQuickPaintedItem::FastFBOResizing);

        m_rect = QRect(0, 0, 2048, 1088);
        m_image = QImage(2048, 1088, QImage::Format_Grayscale8);

        m_expected_width = 2048;
        m_expected_height = 1088;

        m_image.fill(255);
    }

    /**
    * @brief Sets the expected image width.
    *
    * @details Specifies the expected image width, to avoid drawing wrongly set
    * buffers.
    *
    * @param[in] expected_width
    *
    */
    void setExpectedWidth(int expected_width) {
        if (expected_width != m_expected_width) {
            m_expected_width = expected_width;
        }
    }

    /**
    * @brief Sets the expected image height.
    *
    * @details Specifies the expected image height, to avoid drawing wrongly set
    * buffers.
    *
    * @param[in] expected_height
    *
    */
    void setExpectedHeight(int expected_height) {
        if (expected_height != m_expected_height) {
            m_expected_height = expected_height;
        }
    }

    /**
    * @brief Sets the scaling rectangle.
    *
    * @details Specifies the rectangle to scale the image into. Depends on the size
    * of the imagepainter item in the GUI.
    *
    * @param[in] x
    * @param[in] y
    * @param[in] width
    * @param[in] height
    *
    */
    Q_INVOKABLE void setRect(qint32 x, qint32 y, qint32 width, qint32 height) {
        // set rectangle to draw/scale into
        m_rect.setRect(x, y, width, height);
    }

    /**
    * @brief Set the image to draw.
    *
    * @details Sets the image to draw. Depending if it is a container or video image
    * the rotation is applied.
    *
    * @param[in] image The image to draw
    *
    */
    void setImage(QImage image)
    {
        // check if image valid (esp. important when changing to a smaller image)
        if (image.isNull() || m_expected_width != image.width() || m_expected_height != image.height()) {
            return;
        }
        m_image = image;

        // redraw image
        update();
    }

    /**
    * @brief Flushes image to white.
    */
    Q_INVOKABLE void flushImage() {
        m_image.fill(255);
        update();
    }

    /**
    * @brief Redraws to the painter context
    *
    * @details Custom redraw of image. Is executed when update() is called.
    * Scales set image to set rect.
    *
    * @param[in] painter Current QPainter context
    *
    */
    void paint(QPainter *painter) override {
        // draw image into rectangle region
        painter->drawImage(m_rect, m_image);
    }

  private:
    QImage m_image;
    QRect m_rect;
    qint32 m_expected_width;
    qint32 m_expected_height;
};

#endif // MEIMAGEPROVIDER_H
