/*
 * scanCONTROL Developer Tool - GUI application for LLT.dll and linLLT
 *
 * MIT License
 *
 * Copyright © 2017-2019 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#include "mescancontrol.h"
#ifdef _WIN32
#include "meerrormsgeventfilter.h"
#endif
#include "meimagepainter.h"

#include <QtWidgets/QApplication>
#include <QtCore/QLocale>
#include <QtQml/QQmlApplicationEngine>
#include <QtQml/QQmlContext>
#include <QtCore/QUrl>

int main(int argc, char *argv[])
{
    // enable support for high dpi
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    // disable cache
    QCoreApplication::setAttribute(Qt::AA_DisableShaderDiskCache);

    QApplication app(argc, argv);

    // install application icon && info
    app.setWindowIcon(QIcon(":/content/scanCONTROL_DEV.ico"));
    app.setOrganizationName("MICRO-EPSILON");
    app.setOrganizationDomain("micro-epsilon.com");
    app.setApplicationName("scanCONTROL Developer Tool");
    app.setApplicationVersion("1.2");

    // set consistent font
    QFont font("Helvetica");
    font.setStyleHint(QFont::SansSerif, QFont::PreferAntialias);
    font.setPointSizeF(8);
    app.setFont(font);

    // register custom QML types
    qmlRegisterType<MEScanControl>("com.me.scanControl", 1, 0, "MEScanControl");
    qmlRegisterType<MEImagePainter>("com.me.imagePainter", 1, 0, "MEImagePainter");

#ifdef _WIN32
    // install generic window message event filter
    MEErrorMsgEventFilter filter;
    app.installNativeEventFilter(&filter);

    // register Window Id type
    qRegisterMetaType<WId>("WId");
#endif

    QQmlApplicationEngine engine;

    // get path of application directory and make it available in QML
    QUrl appPath(QString("%1").arg(app.applicationDirPath()));
    engine.rootContext()->setContextProperty("appDirPath", appPath);
    engine.rootContext()->setContextProperty("qtVersion", qVersion());
    engine.rootContext()->setContextProperty("dtBuildCode", __DATE__);

    // load main QML file
    engine.load(QUrl(QLatin1String("qrc:/qml/main.qml")));
    if (engine.rootObjects().isEmpty()) {
        return -1;
    }

#ifdef _WIN32    
    // necessary for getting the WinId
    QObject *rootObject = engine.rootObjects().first();
    if (rootObject) {
        QWindow *window = qobject_cast<QWindow *>(rootObject);
        if (window) {
            // set winId to make it available in QML for register error msg
            WId wid = window->winId();
            engine.rootContext()->setContextProperty("WID", wid);
        } else {
            return -1;
        }
    } else {
        return -1;
    }
#endif

    return app.exec();
}
