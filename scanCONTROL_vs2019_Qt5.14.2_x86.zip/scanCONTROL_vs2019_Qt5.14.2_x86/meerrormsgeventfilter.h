/*
 * scanCONTROL Developer Tool - GUI application for LLT.dll and linLLT
 *
 * MIT License
 *
 * Copyright © 2017-2019 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *

 */

#ifndef MEERRORMSGEVENTFILTER_H
#define MEERRORMSGEVENTFILTER_H

#include "mescancontrol.h"
#include <QtCore/QAbstractNativeEventFilter>

/**
* @brief NativeEventFilter for LLT.dll WIN error messages
*
* @details This event filter looks for the generic windows message sent by the LLT.dll when the
* connection is lost (lParam: 10). It is registered with RegisterErrorMsg to msg user space 0x0400.
* In wParam the current QScanControl instance pointer is passed to have access to its signals.
* Thus a connection lost signal can be emitted to the Qt environment.
*
* @author Daniel Rauch, Micro-Epsilon Messtechnik GmbH & Co. KG
* @date 2018-01-03 ‏‎08:41:23 +0100 (Wed, 03 Jan 2018) $
*
*/

class MEErrorMsgEventFilter : public QAbstractNativeEventFilter
{
  public:
    bool nativeEventFilter(const QByteArray &eventType, void *message, long *) override
    {
        if (eventType == "windows_generic_MSG") {
            auto *msg = static_cast<MSG *>(message);
            // if message in user space
            if (msg->message == 0x0400) {
                auto *sc = reinterpret_cast<MEScanControl *>(msg->wParam);

                if (msg->lParam == 10) {
                    // if connection is lost (=ERROR_CONNECTIONLOST)
                    // reset internal state and emit connection lost signal                    
                    sc->m_istransmitting = false;
                    sc->m_isconnected = false;
                    emit sc->connectionLost();
                } else if (msg->lParam == 100) {
                    // if max file size reached
                    emit sc->profileSavingStopped(100, "Maximum file size reached");
                }
            }
        }
        return false; // further handle the message
    }
};

#endif // MEERRORMSGEVENTFILTER_H
