/*
 * scanCONTROL Developer Tool - GUI application for LLT.dll and linLLT
 *
 * MIT License
 *
 * Copyright © 2017-2019 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *

 */

#ifndef QSCANCONTROL_H
#define QSCANCONTROL_H

#ifdef __linux__
#include <llt.h>
#endif

#include <QtNetwork/QHostAddress>
#include <QtCore/QObject>
#include <QtCore/QStringListModel>
#include <QtCore/QVector>
#include <QtCore/QMutex>
#include <QtCharts/QtCharts>
#ifdef _WIN32
#include "InterfaceLLT.h"
#endif

// struct for callback data
// modernize: using TCallbackData = struct {
typedef struct TCallbackData {
    QVector<quint8> buffer;
    quint32 profile_counter;
    quint32 lost_profiles;
    quint32 profiles_per_callback;
    double shutter_open;
    double shutter_close;
    double frame_rate;
    quint16 additional_parameter;
    bool first_run;
    bool new_data;
    QMutex mutex;
} TCallbackData;


/**
* @brief MEScanCONTROL is a Qt Wrapper for LLT.dll / libLLT
*
* @details Wraps the LLT.dll (Windows) / libLLT (Linux) API, so it can be easily used to read and
* write scanCONTROL functionality with Qt. It is interfacable with Qt properties,
* signals and slots without needing to know about scanCONTROL registers addresses/formats.
*
* @author Daniel Rauch, Micro-Epsilon Messtechnik GmbH & Co. KG
* @date 2018-01-03 ‏‎08:41:21 +0100 (Wed, 03 Jan 2018) $
*
*/

class MEScanControl : public QObject
{
    Q_OBJECT

    Q_PROPERTY(quint32 profile_counter READ getProfileCounter)
    Q_PROPERTY(quint32 lost_profiles READ getLostProfiles)
    Q_PROPERTY(quint16 enc_times2 READ getEncTimes2OrDigIn)
    Q_PROPERTY(double saturation READ getSaturation)
    Q_PROPERTY(double current_exposure READ getCurrentExposure)
    Q_PROPERTY(double frame_rate READ getFrameRate)
    Q_PROPERTY(qint32 llt_type READ getLLTType)
    Q_PROPERTY(double scaling READ getLLTScaling)
    Q_PROPERTY(double offset READ getLLTOffset)
    Q_PROPERTY(QString firmware_version READ getFirmwareVersion)
    Q_PROPERTY(QString firmware_minor_version READ getFirmwareMinor)
    Q_PROPERTY(QString firmware_build READ getFirmwareBuild)
    Q_PROPERTY(QString llt_name READ getLLTName)
    Q_PROPERTY(QString llt_option READ getLLTOption)
    Q_PROPERTY(QString lib_version READ getLibVersion NOTIFY libVersionChanged)
#ifdef __linux__
    Q_PROPERTY(QString aravis_version READ getAravisVersion NOTIFY aravisVersionChanged)
#endif

    Q_PROPERTY(quint32 serial_number READ getSerialNumber)
    Q_PROPERTY(QString mac_address READ getMacAddress)
    Q_PROPERTY(QString ip_address READ getIPAddress)
    Q_PROPERTY(QString subnet_mask READ getSubnetMask)
    Q_PROPERTY(QString default_gateway READ getDefaultGateway)

    Q_PROPERTY(bool subsampling READ getIsSubsampling)
    Q_PROPERTY(quint32 image_width READ getImageWidth)
    Q_PROPERTY(quint32 image_height READ getImageHeight)
    Q_PROPERTY(double min_x READ getMinX)
    Q_PROPERTY(double max_x READ getMaxX)
    Q_PROPERTY(double min_z READ getMinZ)
    Q_PROPERTY(double max_z READ getMaxZ)
    Q_PROPERTY(double min_x_scaling READ getMinXScaling)
    Q_PROPERTY(double max_x_scaling READ getMaxXScaling)
    Q_PROPERTY(double min_z_scaling READ getMinZScaling)
    Q_PROPERTY(double max_z_scaling READ getMaxZScaling)
    Q_PROPERTY(double autoscale_threshold READ getAutoscalingThreshold)

    Q_PROPERTY(quint32 resolution READ getResolution WRITE setResolution)
    Q_PROPERTY(QList<int> resolutions READ getResolutions)
    Q_PROPERTY(bool compress_data READ getCompressData WRITE setCompressData)

    Q_PROPERTY(quint32 threshold READ getThreshold WRITE setThreshold)
    Q_PROPERTY(bool threshold_automatic READ getThresholdAutomatic WRITE setThresholdAutomatic)
    Q_PROPERTY(bool ambient_light_suppression READ getAmbientLightSuppression WRITE setAmbientLightSuppression)
    Q_PROPERTY(bool video_filter READ getVideoFilter WRITE setVideoFilter)

    Q_PROPERTY(quint16 min_width READ getMinWidth WRITE setMinWidth)
    Q_PROPERTY(quint16 max_width READ getMaxWidth WRITE setMaxWidth)
    Q_PROPERTY(quint16 min_intensity READ getMinIntensity WRITE setMinIntensity)
    Q_PROPERTY(quint16 max_intensity READ getMaxIntensity WRITE setMaxIntensity)

    Q_PROPERTY(quint32 median_filter READ getMedianFilter WRITE setMedianFilter)
    Q_PROPERTY(quint32 avg_filter READ getAvgFilter WRITE setAvgFilter)
    Q_PROPERTY(quint32 resampling READ getResampling WRITE setResampling)
    Q_PROPERTY(bool interpolate_points READ getInterpolateInvalidPoints WRITE setInterpolateInvalidPoints)
    Q_PROPERTY(bool resample_all_data READ getResampleAllData WRITE setResampleAllData)

    Q_PROPERTY(bool encoder READ getEncoder WRITE setEncoder)
    Q_PROPERTY(bool loopback READ getLoopbackParameters WRITE setLoopbackParameters)
    Q_PROPERTY(quint32 suppress_user_mode READ getSuppressUserModeLoad WRITE setSuppressUserModeLoad)

    Q_PROPERTY(quint32 rs422_function READ getRS422Function WRITE setRS422Function)
    Q_PROPERTY(quint32 digital_input_function READ getDigitalInputFunction WRITE setDigitalInputFunction)
    Q_PROPERTY(quint32 encoder_behaviour READ getEncoderBehaviour WRITE setEncoderBehaviour)
    Q_PROPERTY(bool rs422_termination READ getRS422Termination WRITE setRS422Termination)
    Q_PROPERTY(quint32 logic_level READ getLogicLevel WRITE setLogicLevel)
    Q_PROPERTY(quint32 input_resistor READ getInputResistor WRITE setInputResistor)

    Q_PROPERTY(quint32 reflection_processing READ getReflectionProcessing WRITE setReflectionProcessing)
    Q_PROPERTY(bool high_resolution READ getHighResolution WRITE setHighResolution)
    Q_PROPERTY(bool post_processing READ getPostProcessing WRITE setPostProcessing)
    Q_PROPERTY(bool flip_position READ getFlipPosition WRITE setFlipPosition)
    Q_PROPERTY(bool flip_distance READ getFlipDistance WRITE setFlipDistance)
    Q_PROPERTY(bool calibration READ getCalibration WRITE setCalibration)
    Q_PROPERTY(quint32 exposure_alignment READ getExposureAlignment WRITE setExposureAlignment)
    Q_PROPERTY(quint32 auto_exposure_algo READ getAutoExposureAlgo WRITE setAutoExposureAlgo)

    Q_PROPERTY(double exposure_time READ getExposureTime WRITE setExposureTime)
    Q_PROPERTY(double second_exposure_time READ getSecondExposureTime WRITE setSecondExposureTime)
    Q_PROPERTY(double profile_frequency READ getProfileFrequency WRITE setProfileFrequency NOTIFY profileFrequencyChanged)
    Q_PROPERTY(bool auto_exposure READ getAutoExposure WRITE setAutoExposure)

    Q_PROPERTY(quint32 laser_power READ getLaserPower WRITE setLaserPower)
    Q_PROPERTY(bool pulse_mode READ getPulseMode WRITE setPulseMode)

    Q_PROPERTY(quint32 trigger_mode READ getTriggerMode WRITE setTriggerMode)
    Q_PROPERTY(quint32 trigger_input READ getTriggerInput WRITE setTriggerInput)
    Q_PROPERTY(quint32 encoder_divider READ getEncoderDivider WRITE setEncoderDivider)

    Q_PROPERTY(double auto_exposure_min READ getAutoExposureMin WRITE setAutoExposureMin)
    Q_PROPERTY(double auto_exposure_max READ getAutoExposureMax WRITE setAutoExposureMax)
    Q_PROPERTY(quint32 roi1_preset READ getRoi1Preset WRITE setRoi1Preset)
    Q_PROPERTY(bool roi1_free_region READ getRoi1FreeRegion WRITE setRoi1FreeRegion)

    Q_PROPERTY(quint16 roi1_start_x READ getRoi1StartX WRITE setRoi1StartX)
    Q_PROPERTY(quint16 roi1_end_x READ getRoi1EndX WRITE setRoi1EndX)
    Q_PROPERTY(quint16 roi1_start_z READ getRoi1StartZ WRITE setRoi1StartZ)
    Q_PROPERTY(quint16 roi1_end_z READ getRoi1EndZ WRITE setRoi1EndZ)

    Q_PROPERTY(bool calib_active READ getCalibActive WRITE setCalibActive)
    Q_PROPERTY(double calib_rot_angle READ getCalibRotAngle WRITE setCalibRotAngle)
    Q_PROPERTY(double calib_translate_x READ getCalibTranslateX WRITE setCalibTranslateX)
    Q_PROPERTY(double calib_translate_z READ getCalibTranslateZ WRITE setCalibTranslateZ)

    Q_PROPERTY(quint16 roi2_start_x READ getRoi2StartX WRITE setRoi2StartX)
    Q_PROPERTY(quint16 roi2_end_x READ getRoi2EndX WRITE setRoi2EndX)
    Q_PROPERTY(quint16 roi2_start_z READ getRoi2StartZ WRITE setRoi2StartZ)
    Q_PROPERTY(quint16 roi2_end_z READ getRoi2EndZ WRITE setRoi2EndZ)
    Q_PROPERTY(quint16 roni_x_start READ getRoniStartX WRITE setRoniStartX)
    Q_PROPERTY(quint16 roni_x_end READ getRoniEndX WRITE setRoniEndX)
    Q_PROPERTY(quint16 roni_z_start READ getRoniStartZ WRITE setRoniStartZ)
    Q_PROPERTY(quint16 roni_z_end READ getRoniEndZ WRITE setRoniEndZ)
    Q_PROPERTY(quint16 ea_ref_start_x READ getEARefStartX WRITE setEARefStartX)
    Q_PROPERTY(quint16 ea_ref_end_x READ getEARefEndX WRITE setEARefEndX)
    Q_PROPERTY(quint16 ea_ref_start_z READ getEARefStartZ WRITE setEARefStartZ)
    Q_PROPERTY(quint16 ea_ref_end_z READ getEARefEndZ WRITE setEARefEndZ)
    Q_PROPERTY(bool roi2 READ getRoi2 WRITE setRoi2)
    Q_PROPERTY(bool roni READ getRoni WRITE setRoni)
    Q_PROPERTY(bool ea_ref READ getEARef WRITE setEARef)
    Q_PROPERTY(qint32 profile_mode READ getProfileMode WRITE setProfileMode)

    Q_PROPERTY(quint32 packet_delay READ getPacketDelay WRITE setPacketDelay)
    Q_PROPERTY(quint32 user_mode READ getUserMode)

    Q_PROPERTY(quint32 ethernet_heartbeat_timeout READ getEthernetHeartbeatTimeout WRITE setEthernetHeartbeatTimeout)
    Q_PROPERTY(quint32 buffer_count READ getBufferCount WRITE setBufferCount)
    Q_PROPERTY(quint32 packet_size READ getPacketSize WRITE setPacketSize)

    Q_PROPERTY(bool container_x READ getContainerX WRITE setContainerX)
    Q_PROPERTY(bool container_z READ getContainerZ WRITE setContainerZ)
    Q_PROPERTY(bool container_threshold READ getContainerThreshold WRITE setContainerThreshold)
    Q_PROPERTY(bool container_intensity READ getContainerIntensity WRITE setContainerIntensity)
    Q_PROPERTY(bool container_width READ getContainerWidth WRITE setContainerWidth)
    Q_PROPERTY(bool container_moment0 READ getContainerMoment0 WRITE setContainerMoment0)
    Q_PROPERTY(bool container_moment0Upper READ getContainerMoment0Upper WRITE setContainerMoment0Upper)
    Q_PROPERTY(bool container_moment1 READ getContainerMoment1 WRITE setContainerMoment1)
    Q_PROPERTY(bool container_moment1Upper READ getContainerMoment1Upper WRITE setContainerMoment1Upper)
    Q_PROPERTY(bool container_loopback READ getContainerLoopback WRITE setContainerLoopback)
    Q_PROPERTY(bool container_timestamp READ getContainerTimestamp WRITE setContainerTimestamp)
    Q_PROPERTY(bool container_timestamp_field READ getContainerTimestampField WRITE setContainerTimestampField)
    Q_PROPERTY(bool container_littleendian READ getContainerLittleEndian WRITE setContainerLittleEndian)
    Q_PROPERTY(bool container_signed READ getContainerSigned WRITE setContainerSigned)
    Q_PROPERTY(bool container_join READ getContainerJoin WRITE setContainerJoin)
    Q_PROPERTY(bool container_stripe1 READ getContainerStripe1 WRITE setContainerStripe1)
    Q_PROPERTY(bool container_stripe2 READ getContainerStripe2 WRITE setContainerStripe2)
    Q_PROPERTY(bool container_stripe3 READ getContainerStripe3 WRITE setContainerStripe3)
    Q_PROPERTY(bool container_stripe4 READ getContainerStripe4 WRITE setContainerStripe4)
    Q_PROPERTY(quint32 profiles_per_container READ getProfilesPerContainer WRITE setProfilesPerContainer)

    Q_PROPERTY(qint32 profile_config MEMBER m_profile_config WRITE setProfileConfig)
    Q_PROPERTY(qint32 reflection MEMBER m_reflection WRITE setReflection)
    Q_PROPERTY(qint32 selected_index MEMBER m_selected_index)
    Q_PROPERTY(bool import_calibration MEMBER m_import_calibration WRITE setImportCalibration)
    Q_PROPERTY(qint32 external_scanner_type MEMBER m_external_scanner_type WRITE setExternalScannerType)
    Q_PROPERTY(qint32 video_mode MEMBER m_video_mode WRITE setVideoMode)

    Q_PROPERTY(QImage video_image READ getVideoImage)
    Q_PROPERTY(QImage container_image READ getContainerImage)

#ifdef _WIN32
    Q_PROPERTY(WId wid MEMBER m_wid WRITE setWid)
    Q_PROPERTY(quint32 max_file_size READ getMaxFileSize WRITE setMaxFileSize)
#endif
    Q_PROPERTY(bool expert_mode MEMBER m_expert_mode)

  public:
    MEScanControl();
    // ~MEScanControl() override;

    // # SETTER #

    // ### set transmission properties ###

    void setProfileConfig(qint32 profile_config);
    void setReflection(quint32 reflection) {
        m_callback_data->new_data = true;
        m_reflection = reflection;
    }

    // ### set misc properties ###
    void setImportCalibration(bool import_calibration) { m_import_calibration = import_calibration; }
    void setExternalScannerType(qint32 external_scanner_type) { m_external_scanner_type = (TScannerType)external_scanner_type; }
    void setVideoMode(qint32 video_mode) { m_video_mode = (TTransferVideoType)video_mode; }
#ifdef _WIN32
    void setWid(WId wid) { m_wid = wid; }
    void setMaxFileSize(quint32 buffer_count);
#endif

    // ### set features ###

    // misc
    void setResolution(quint32 resolution);
    void setCompressData(bool compress);
    void setEthernetHeartbeatTimeout(quint32 timeout_in_ms);
    void setPacketSize(quint32 packet_size);
    void setBufferCount(quint32 buffer_count);

    // threshold
    void setThreshold(quint32 threshold);
    void setThresholdAutomatic(bool active);
    void setAmbientLightSuppression(bool active);
    void setVideoFilter(bool active);

    // peak filter
    void setMinWidth(quint16 min_width);
    void setMaxWidth(quint16 max_width);
    void setMinIntensity(quint16 min_intensity);
    void setMaxIntensity(quint16 max_intensity);

    // filter
    void setMedianFilter(quint32 filter_taps);
    void setAvgFilter(quint32 filter_taps);
    void setResampling(quint32 range);
    void setInterpolateInvalidPoints(bool active);
    void setResampleAllData(bool active);

    // maintenance
    void setEncoder(bool active);
    void setLoopbackParameters(bool active);
    void setSuppressUserModeLoad(quint32 state);

    // multiport
    void setRS422Function(quint32 state);
    void setDigitalInputFunction(quint32 state);
    void setEncoderBehaviour(quint32 state);
    void setRS422Termination(bool active);
    void setLogicLevel(quint32 state);
    void setInputResistor(quint32 state);

    // post processing
    void setReflectionProcessing(quint32 state);
    void setHighResolution(bool active);
    void setPostProcessing(bool active);
    void setFlipPosition(bool active);
    void setFlipDistance(bool active);
    void setCalibration(bool active);
    void setExposureAlignment(quint32 state);
    void setAutoExposureAlgo(quint32 state);

    // timing
    void setExposureTime(double exposure);
    void setSecondExposureTime(double exposure);
    void setProfileFrequency(double frequency);
    void setAutoExposure(bool active);
    void setAutoExposureMin(double exposure_min);
    void setAutoExposureMax(double exposure_max);

    // laser
    void setLaserPower(quint32 state);
    void setPulseMode(bool active);

    // trigger
    void setTriggerMode(quint32 mode);
    void setTriggerInput(quint32 input);
    void setEncoderDivider(quint32 divisor);

    // measuring field
    void setRoi1Preset(quint32 number);
    void setRoi1FreeRegion(bool active);
    void setRoi1StartX(quint16 x_start);
    void setRoi1EndX(quint16 x_end);
    void setRoi1StartZ(quint16 z_start);
    void setRoi1EndZ(quint16 z_end);
    void setRoi2StartX(quint16 x_start);
    void setRoi2EndX(quint16 x_end);
    void setRoi2StartZ(quint16 z_start);
    void setRoi2EndZ(quint16 z_end);
    void setRoniStartX(quint16 x_start);
    void setRoniEndX(quint16 x_end);
    void setRoniStartZ(quint16 z_start);
    void setRoniEndZ(quint16 z_end);
    void setEARefStartX(quint16 x_start);
    void setEARefEndX(quint16 x_end);
    void setEARefStartZ(quint16 z_start);
    void setEARefEndZ(quint16 z_end);
    void setRoi2(bool active);
    void setRoni(bool active);
    void setEARef(bool active);

    void setProfileMode(qint32 mode);

    // packet delay
    void setPacketDelay(quint32 delay_in_us);

    // container
    void setContainerX(bool active);
    void setContainerZ(bool active);
    void setContainerThreshold(bool active);
    void setContainerIntensity(bool active);
    void setContainerWidth(bool active);
    void setContainerMoment0(bool active);
    void setContainerMoment0Upper(bool active);
    void setContainerMoment1(bool active);
    void setContainerMoment1Upper(bool active);
    void setContainerLoopback(bool active);
    void setContainerTimestamp(bool active);
    void setContainerTimestampField(bool active);
    void setContainerLittleEndian(bool active);
    void setContainerSigned(bool active);
    void setContainerJoin(bool active);
    void setContainerStripe1(bool active);
    void setContainerStripe2(bool active);
    void setContainerStripe3(bool active);
    void setContainerStripe4(bool active);
    void setProfilesPerContainer(quint32 profile_per_container);

    // calibration
    void setCalibActive(bool active);
    void setCalibRotAngle(double angle);
    void setCalibTranslateX(double sX);
    void setCalibTranslateZ(double sZ);

    // # GETTER #

    // ### get basic scanner info ###

#ifdef _WIN32
    quint32 getMaxFileSize();
#elif __linux__
    QString getAravisVersion();
#endif

    QString getLibVersion();

    qint32 getLLTType() const { return m_scanner_type; }
    QString getFirmwareVersion();
    QString getFirmwareMinor();
    QString getFirmwareBuild();
    QString getLLTName();
    QString getLLTOption();
    bool getIsSubsampling() const { return m_issubsampling; }
    quint32 getSerialNumber();
    QString getMacAddress();
    QString getIPAddress();
    QString getSubnetMask();
    QString getDefaultGateway();

    // ### get transmission meta data ###

    double getSaturation() const { return m_saturation; }
    quint32 getLostProfiles() const { return m_callback_data->lost_profiles; }
    quint32 getProfileCounter() const { return m_callback_data->profile_counter; }
    quint16 getEncTimes2OrDigIn() const { return m_callback_data->additional_parameter; }
    double getCurrentExposure() const { return m_current_exposure; }
    double getFrameRate() const { return m_callback_data->frame_rate; }
    double getLLTScaling() const { return m_scaling; }
    double getLLTOffset() const { return m_offset; }

    double getMinX() const { return m_min_x; }
    double getMaxX() const { return m_max_x; }
    double getMinZ() const { return m_min_z; }
    double getMaxZ() const { return m_max_z; }
    double getAutoscalingThreshold() const { return AUTOSCALING_SIGNAL_THRESHOLD; }
    double getMinXScaling() const { return m_min_x_scaling; }
    double getMaxXScaling() const { return m_max_x_scaling; }
    double getMinZScaling() const { return m_min_z_scaling; }
    double getMaxZScaling() const { return m_max_z_scaling; }

    // ### image painter properties ###

    QImage getVideoImage();
    QImage getContainerImage();
    quint32 getImageWidth() const { return m_image_width; }
    quint32 getImageHeight() const { return m_image_height; }

    // ### get features ###

    // misc
    quint32 getResolution();
    QList<int> getResolutions() const { return m_resolutions; }
    bool getCompressData();
    quint32 getEthernetHeartbeatTimeout();
    quint32 getPacketSize();
    quint32 getBufferCount();

    // threshold
    quint32 getThreshold();
    bool getThresholdAutomatic();
    bool getAmbientLightSuppression();
    bool getVideoFilter();

    // peak filter
    quint16 getMinWidth();
    quint16 getMaxWidth();
    quint16 getMinIntensity();
    quint16 getMaxIntensity();

    // filter
    quint32 getMedianFilter();
    quint32 getAvgFilter();
    quint32 getResampling();
    bool getInterpolateInvalidPoints();
    bool getResampleAllData();

    // maintenance
    bool getEncoder();
    bool getLoopbackParameters();
    quint32 getSuppressUserModeLoad();

    // digitalIO
    quint32 getRS422Function();
    quint32 getDigitalInputFunction();
    quint32 getEncoderBehaviour();
    quint32 getRS422Termination();
    quint32 getLogicLevel();
    quint32 getInputResistor();

    // post processing
    quint32 getReflectionProcessing();
    bool getHighResolution();
    bool getPostProcessing();
    bool getFlipPosition();
    bool getFlipDistance();
    bool getCalibration();
    quint32 getExposureAlignment();
    quint32 getAutoExposureAlgo();

    // timing
    double getExposureTime();
    double getSecondExposureTime();
    double getProfileFrequency();
    bool getAutoExposure();
    double getAutoExposureMin();
    double getAutoExposureMax();

    // laser
    quint32 getLaserPower();
    bool getPulseMode();

    // trigger
    quint32 getTriggerMode();
    quint32 getTriggerInput();
    quint32 getEncoderDivider();

    // regions
    quint32 getRoi1Preset();
    bool getRoi1FreeRegion();
    quint16 getRoi1StartX();
    quint16 getRoi1EndX();
    quint16 getRoi1StartZ();
    quint16 getRoi1EndZ();
    quint16 getRoi2StartX();
    quint16 getRoi2EndX();
    quint16 getRoi2StartZ();
    quint16 getRoi2EndZ();
    quint16 getRoniStartX();
    quint16 getRoniEndX();
    quint16 getRoniStartZ();
    quint16 getRoniEndZ();
    quint16 getEARefStartX();
    quint16 getEARefEndX();
    quint16 getEARefStartZ();
    quint16 getEARefEndZ();
    bool    getRoi2();
    bool    getRoni();
    bool    getEARef();

    qint32  getProfileMode();

    // packet delay
    quint32 getPacketDelay();
    quint32 getUserMode();

    // container
    bool getContainerX();
    bool getContainerZ();
    bool getContainerThreshold();
    bool getContainerIntensity();
    bool getContainerWidth();
    bool getContainerMoment0Upper();
    bool getContainerMoment0();
    bool getContainerMoment1Upper();
    bool getContainerMoment1();
    bool getContainerLoopback();
    bool getContainerTimestamp();
    bool getContainerTimestampField();
    bool getContainerLittleEndian();
    bool getContainerSigned();
    bool getContainerJoin();
    bool getContainerStripe1();
    bool getContainerStripe2();
    bool getContainerStripe3();
    bool getContainerStripe4();
    quint32 getProfilesPerContainer();

    // calibration
    bool getCalibActive();
    double getCalibRotAngle();
    double getCalibTranslateX();
    double getCalibTranslateZ();

    // sensor status
    bool m_istransmitting;
    bool m_isconnected;

  public slots:
    // scan interface
    void scanInterface();
    void setIPAddress(QString ip);

    // connection state
    void connectSensor();
    void disconnectSensor();

    // transfer state
    void startTransfer();
    void stopTransfer();

    // additional scanner commands
    void setFreeMeasuringField(double column_start, double column_end, double row_start, double row_end);
    void setCustomCalibration(double angle, double sX, double sZ);
    void resetCustomCalibration();
    void setPeakFilter(quint16 min_width, quint16 max_width, quint16 min_intens, quint16 max_intens);    
    void setPartialProfile(quint32 data_start, quint32 data_size, quint32 point_start, quint32 number_points);
    //void setCmmTriggerFeatures(qint32 mark_space_ration, double skew_correction, quint32 divisor);
    void loadFromUserMode(quint32 user_mode);
    void saveToUserMode(quint32 user_mode);
    void softwareTriggerProfile();
    void softwareTriggerContainer();
    void softwareFlushContainer();
    void containerTriggerEnable(bool enable);
    void saveVideoImage2Bmp(const QUrl &path);
    void saveContainerImage2Png(const QUrl& path);
    void getSensorInfo(QString host_ip);

    // config file handling
    void importLLTConfig(const QUrl& path);
    void exportLLTConfig(const QUrl &path);
    void exportPostProcessingParams(const QUrl &path);

    // global parameters
    void saveGlobalParameters();

#ifdef _WIN32
    // save & load profiles
    void loadProfiles(const QUrl& path);
    void saveProfiles(const QUrl& path);
    void stopLoading();
    void stopSaving();
    void changeDisplayedProfile(qint32 position);
    void saveProfileCsv(const QUrl& path);
#endif
    // profile graph handling
    //void updateProfileData(QAbstractSeries *series);
    void updateProfileData(QAbstractSeries *line_series,
                           QAbstractSeries *low_series, QAbstractSeries *normal_series, QAbstractSeries *high_series,
                           bool is_dynamic, bool plot_line, bool plot_invalid_points, bool autoscaling);
    void resetProfileData(QAbstractSeries *series);

  signals:
    void scanInterfaceChanged(qint32 number_devices, QStringList ip_addresses,
                              QStringList serial_number, QStringList types);
    void getDeviceInfoFinished(qint32 sensors_found, QStringList sensor_names, QStringList ip_addresses,
                               QStringList serial_number, QStringList mac_addresses);

    void ipAddressSet(qint32 status, QString msg);

    void libVersionChanged(QString lib_version);
#ifdef __linux__
    void aravisVersionChanged(QString lib_version);    
#endif

    void sensorConnected(qint32 status, QString msg);
    void sensorDisconnected(qint32 status, QString msg);

    void transferStarted(qint32 status, QString msg);
    void transferStopped(qint32 status, QString msg);

    void profileFrequencyChanged(double profile_frequency, bool exposure_limited);
    void autoscalingThresholdExceeded(double thresholded_min_x, double thresholded_max_x,
                                      double thresholded_min_z, double thresholded_max_z);

    void importConfigFinished(qint32 status, QString msg, QString path);
    void exportConfigFinished(qint32 status, QString msg, QString path);

    void userModeLoaded(qint32 status, QString msg, quint32 user_mode);
    void userModeSaved(qint32 status, QString msg, quint32 user_mode);

    void profileSavingStarted(int status, QString msg, QString path);
    void profileSavingStopped(qint32 status, QString msg);
    void profileLoaded(int status, QString msg, QString path);
    void profileLoadingStopped(qint32 status, QString msg);
    void loadedProfileChanged(qint32 status, QString msg);
    void profileSavingAsCsvStarted(int status, QString msg, QString path);
    void videoImageSaved(bool status, QString path);

    void connectionLost();
    void errorSensorFeature(qint32 status, QString msg);

  private:

    // constants
    static const qint32 MAX_SCANNERS_ON_IF = 15;
    static const qint32 MAX_ERROR_MESSAGE_LENGTH = 111;

    static const qint32 INTENSITY_THRESHOLD_LOW = 650;
    static const qint32 INTENSITY_THRESHOLD_HIGH = 950;

    static constexpr double AUTOSCALING_SIGNAL_THRESHOLD = 0.2;
    static constexpr double PI = 3.14159265;

    QScopedPointer<CInterfaceLLT> m_hllt;
    QScopedPointer<TCallbackData> m_callback_data;

    QString m_lib_version;

#ifdef __linux__
    QStringList m_found_devices;
#elif _WIN32
    QVector<quint32> m_interfaces;
    WId m_wid;
#endif
    qint32 m_selected_index;

    QVector<double> m_x_value, m_z_value;
    QVector<quint16> m_intensity, m_threshold;
    QVector<QPointF> m_points;
    QVector<quint8> m_mono8;
    quint32 m_reflection;

    TProfileConfig m_profile_config;
    TPartialProfile m_partial_profile;
    TScannerType m_scanner_type;
    TScannerType m_external_scanner_type;
    TTransferVideoType m_video_mode;

    quint32 m_resolution;
    QList<int> m_resolutions;
    quint32 m_hdr_factor;
    bool m_issubsampling;

    bool m_ismirrored_x, m_ismirrored_z;
    double m_saturation, m_current_exposure;

    double m_min_z, m_max_z, m_min_x, m_max_x;
    double m_old_min_x, m_old_max_x, m_old_min_z, m_old_max_z;
    double m_min_x_scaling, m_max_x_scaling, m_min_z_scaling, m_max_z_scaling;


    double m_scaling, m_offset;

    bool m_profiles_loaded;
    qint32 m_previous_loaded_profile;
    bool m_import_calibration;
    bool m_expert_mode;
    bool m_is_hdr;

    quint32 m_image_width, m_image_height;
    QImage m_video_image;
    QImage m_container_image;

    // helper functions
    static QString evalRetVal(qint32 ret);
    void setIntFeature2Sensor(quint32 feature, quint32 state, quint32 bitmask);
    void setBoolFeature2Sensor(quint32 feature, bool active, quint32 bitmask);
    bool getBoolFeatureFromSensor(quint32 feature, quint32 bitmask);
    quint32 getIntFeatureFromSensor(quint32 feature, quint32 shift, quint32 bitmask);

    void setFieldStart(quint16 start, quint32 feature, bool mirrored);
    quint16 getFieldStart(quint32 feature, bool mirrored);
    void setFieldEnd(quint16 end, quint32 feature, bool mirrored);
    quint16 getFieldEnd(quint32 feature, bool mirrored);
    QString getDeviceName();
    void getDisplayScaling(double &min_x_scaling, double &max_x_scaling, double &min_z_scaling, double &max_z_scaling);
};

#endif // QSCANCONTROL_H
