﻿修改：vs2019+Qt5.14.2 msvc32位 debug成功


--------------------------------
   scanCONTROL Developer Tool
--------------------------------
Current version 1.4

About the tool:
---------------
- The Developer Tool reads and writes sensor settings.
- The Container image is only shown correctly if “Little Endian” (=GigE Mode) is used. This is by design, to show the difference between the settings.
- A longer mouse over yields infos how to set the respective parameter in the SDK
- Firmware versions <v43 don’t support reading out the EXTRA_PARAMETERS, thus you get a warning; setting is possible via the legacy mode
- For the source code check download package, redownload package(https://www.micro-epsilon.de/2D_3D/laser-scanner/Software/downloads/) or ask at info@micro-epsilon.de
- The scanCONTROL Developer Tool project is licensed under GPLv3, some useful source code files are additionally available under MIT license

Additonal remarks about licensing:
----------------------------------
- This tool was developed and made open source to be used with the Linux operating system and a wrapped LGPL library called aravis (https://github.com/AravisProject/aravis).
- To optionally extend the usage to Windows the corresponding distribution contains a non-free library which is loaded during runtime (LLT.dll).
  Please replace this library with free software, if available.

Known issues:
-------------
- Default DllLoader and Interface_2 class + scanControlDataTypes.h had to be adjusted -> clean solution to be discussed
- Intel had one/two bad drivers, breaking _all_ OpenGL/QML-dependent Qt applications (blurry text, misalignment, crashes). 
  See here https://bugreports.qt.io/browse/QTBUG-63508 or directly here https://communities.intel.com/thread/116003. 
  A Intel driver update solves the issue.
- Due to Qt Platform Menubar not supporting GNOME, the non-platform specific Menubar has to be used.
  To do so delete "Platform." in main.qml and assign the MenuBar to the property "menuBar".

Linux use:
-------------
- The tool can be built in Linux.
- Following packages/libs are needed:
	QT (including QT Creator)
	Aravis
	LibXML2 and libXML2—dev
- Open the scanCONTROL_Developer_Tool.pro in QT Creator, build and run Developer Tool.

Release Notes:
--------------
v1.4 - 21.04.21
- Support for 30xx-100
- Support for 30x2
- Fixed: lost profiles counter at profile counter overrun
- Added: Container Mode M0/M1 separate selection of Low/High word

v1.3.3
- 30xx-200: Set/Get ROI fixed

v1.3.2 - 03.06.2020
- LLT.dll bugfixed
- Set ethernet heartbeat timeout for saving user modes
- scanCONTROL 30xx-200 support added

v1.3.1 - 17.02.2020 (internal release)
- disable shader cache
- Linux support description added
- .zip compression fixed

v1.3.0 - 28.10.2019
- Added support for scanCONTROL 25xx series

v1.2.0 - 01.07.2019
- Added support for setting exposure time/idle time in 1µs steps (only scanCONTROL 30xx)
- Added Trigger Container Function
- Added Exposure queue (only expert mode)

v1.1.0 - 26.04.2019
- Added support for scanCONTROL 30xx series (25 mm, 50 mm)
- Added save profiles (Win only)
- Added support for custom calibration function of scanCONTROL
- Added compress bit for sensors >= FW v46
- Added Expert Mode (F12)
- Added convenience start/stop
- Added Infomenu which shows additional sensor meta data
- Added profile plot autoscaling
- More flexible profile plot representation (grid & point size, dynamic colors, 
  invalid points, line plot, zoom factor, center of measuring range, ...)
- Axis now usable for separated x or y scaling/shifting
- Meas field ROI resizable via mouse
- Disable Tooltips option
- Added "About..." dialog
- Save window size/state and plot settings between restarts
- Better UI element handling
- Show connection state
- OS native menubar (not working for GNOME based distros; here follow instructions in main.qml to display the menubar)

v1.0.0 - 30.05.2018
- Initial Release