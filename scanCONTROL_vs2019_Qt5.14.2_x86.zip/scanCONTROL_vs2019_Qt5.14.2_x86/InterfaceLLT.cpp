//  InterfaceLLT.cpp: CInterfaceLLT class.
//
//   Version 3.7.0.0
//
//   Copyright 2010
//
//   Sebastian Lueth
//   MICRO-EPSILON Optronic GmbH
//   Lessingstrasse 14
//   01465 Dresden OT Langebrueck
//   Germany

//   DRA: adjusted to comply with parts of Linux SDK, e.g. more info
//   from Timestamp and static functions if possible
//   We should search for a flexible, offical solution to this issue

#include "InterfaceLLT.h"
#include "DllLoader.h"
#include "stdafx.h"
#include <math.h>

// constructor of the InterfaceLLT class
// the constructor loads the LLT.dll and request all now supported
// function-pointers so you can easy us the function of the dll
CInterfaceLLT::CFunctions::CFunctions(const char *pDLLName /*= "LLT.dll"*/, bool *pLoadError /*=NULL*/)
{
    if (pLoadError)
        *pLoadError = false;

    m_pDllLoader = new CDllLoader(pDLLName, pLoadError);
    m_dll_version = m_pDllLoader->getFileVersion();

    // Instance functions
    CreateLLTDevice = (TInterfaceCreateLLTDevice)m_pDllLoader->GetFunction("s_CreateLLTDevice");
    CreateLLTFirewire = (TInterfaceCreateLLTFirewire)m_pDllLoader->GetFunction("s_CreateLLTFirewire");
    CreateLLTSerial = (TInterfaceCreateLLTSerial)m_pDllLoader->GetFunction("s_CreateLLTSerial");
    GetInterfaceType = (TInterfaceGetInterfaceType)m_pDllLoader->GetFunction("s_GetInterfaceType");
    DelDevice = (TInterfaceDelDevice)m_pDllLoader->GetFunction("s_DelDevice");

    // Connect functions
    Connect = (TInterfaceConnect)m_pDllLoader->GetFunction("s_Connect");
    Disconnect = (TInterfaceDisconnect)m_pDllLoader->GetFunction("s_Disconnect");

    // Read/Write config functions
    ExportLLTConfig = (TInterfaceExportLLTConfig)m_pDllLoader->GetFunction("s_ExportLLTConfig");
    ExportLLTConfigString = (TInterfaceExportLLTConfigString)m_pDllLoader->GetFunction("s_ExportLLTConfigString");
    ImportLLTConfig = (TInterfaceImportLLTConfig)m_pDllLoader->GetFunction("s_ImportLLTConfig");
    ImportLLTConfigString = (TInterfaceImportLLTConfigString)m_pDllLoader->GetFunction("s_ImportLLTConfigString");

    // Device interface functions
    GetDeviceInterfaces = (TInterfaceGetDeviceInterfaces)m_pDllLoader->GetFunction("s_GetDeviceInterfaces");
    GetDeviceInterfacesFast = (TInterfaceGetDeviceInterfacesFast)m_pDllLoader->GetFunction("s_GetDeviceInterfacesFast");
    SetDeviceInterface = (TInterfaceSetDeviceInterface)m_pDllLoader->GetFunction("s_SetDeviceInterface");
    GetDiscoveryBroadcastTarget = (TInterfaceGetDiscoveryBroadcastTarget)m_pDllLoader->GetFunction("s_GetDiscoveryBroadcastTarget");
    SetDiscoveryBroadcastTarget = (TInterfaceSetDiscoveryBroadcastTarget)m_pDllLoader->GetFunction("s_SetDiscoveryBroadcastTarget");

    // scanCONTROL indentification functions
    GetDeviceName = (TInterfaceGetDeviceName)m_pDllLoader->GetFunction("s_GetDeviceName");
    GetSerialNumber = (TInterfaceGetSerialNumber)m_pDllLoader->GetFunction("s_GetSerialNumber");
    GetLLTVersions = (TInterfaceGetLLTVersions)m_pDllLoader->GetFunction("s_GetLLTVersions");
    GetLLTType = (TInterfaceGetLLTType)m_pDllLoader->GetFunction("s_GetLLTType");

    // Get functions
    GetMinMaxPacketSize = (TInterfaceGetMinMaxPacketSize)m_pDllLoader->GetFunction("s_GetMinMaxPacketSize");
    GetResolutions = (TInterfaceGetResolutions)m_pDllLoader->GetFunction("s_GetResolutions");

    GetFeature = (TInterfaceGetFeature)m_pDllLoader->GetFunction("s_GetFeature");
    GetBufferCount = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetBufferCount");
    GetMainReflection = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetMainReflection");
    GetMaxFileSize = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetMaxFileSize");
    GetPacketSize = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetPacketSize");
    GetFirewireConnectionSpeed = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetFirewireConnectionSpeed");
    GetProfileConfig = (TInterfaceGetProfileConfig)m_pDllLoader->GetFunction("s_GetProfileConfig");
    GetResolution = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetResolution");
    GetProfileContainerSize = (TInterfaceGetProfileContainerSize)m_pDllLoader->GetFunction("s_GetProfileContainerSize");
    GetMaxProfileContainerSize = (TInterfaceGetMaxProfileContainerSize)m_pDllLoader->GetFunction("s_GetMaxProfileContainerSize");
    GetEthernetHeartbeatTimeout = (TInterfaceGetValue)m_pDllLoader->GetFunction("s_GetEthernetHeartbeatTimeout");

    // Set functions
    SetFeature = (TInterfaceSetFeature)m_pDllLoader->GetFunction("s_SetFeature");
    SetFeatureGroup = (TInterfaceSetFeatureGroup)m_pDllLoader->GetFunction("s_SetFeatureGroup");
    SetBufferCount = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetBufferCount");
    SetMainReflection = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetMainReflection");
    SetMaxFileSize = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetMaxFileSize");
    SetPacketSize = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetPacketSize");
    SetFirewireConnectionSpeed = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetFirewireConnectionSpeed");
    SetProfileConfig = (TInterfaceSetProfileConfig)m_pDllLoader->GetFunction("s_SetProfileConfig");
    SetResolution = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetResolution");
    SetProfileContainerSize = (TInterfaceSetProfileContainerSize)m_pDllLoader->GetFunction("s_SetProfileContainerSize");
    SetEthernetHeartbeatTimeout = (TInterfaceSetValue)m_pDllLoader->GetFunction("s_SetEthernetHeartbeatTimeout");

    // Register functions
    RegisterCallback = (TInterfaceRegisterCallback)m_pDllLoader->GetFunction("s_RegisterCallback");
    RegisterErrorMsg = (TInterfaceRegisterErrorMsg)m_pDllLoader->GetFunction("s_RegisterErrorMsg");

    // Profile transfer functions
    TransferProfiles = (TInterfaceTransferProfiles)m_pDllLoader->GetFunction("s_TransferProfiles");
    TransferVideoStream = (TInterfaceTransferVideoStream)m_pDllLoader->GetFunction("s_TransferVideoStream");
    GetProfile = (TInterfaceGetProfile)m_pDllLoader->GetFunction("s_GetProfile");
    MultiShot = (TInterfaceMultiShot)m_pDllLoader->GetFunction("s_MultiShot");
    GetActualProfile = (TInterfaceGetActualProfile)m_pDllLoader->GetFunction("s_GetActualProfile");
    ConvertProfile2Values = (TInterfaceConvertProfile2Values)m_pDllLoader->GetFunction("s_ConvertProfile2Values");
    ConvertPartProfile2Values =
            (TInterfaceConvertPartProfile2Values)m_pDllLoader->GetFunction("s_ConvertPartProfile2Values");
    SetHoldBuffersForPolling = (TInterfaceSetHoldBuffersForPolling)m_pDllLoader->GetFunction("s_SetHoldBuffersForPolling");
    GetHoldBuffersForPolling = (TInterfaceGetHoldBuffersForPolling)m_pDllLoader->GetFunction("s_GetHoldBuffersForPolling");
    TriggerProfile = (TInterfaceTriggerProfile)m_pDllLoader->GetFunction("s_TriggerProfile");
    TriggerContainer = (TInterfaceTriggerContainer)m_pDllLoader->GetFunction("s_TriggerContainer");
    ContainerTriggerEnable = (TInterfaceContainerTriggerEnable)m_pDllLoader->GetFunction("s_ContainerTriggerEnable");
    ContainerTriggerDisable = (TInterfaceContainerTriggerDisable)m_pDllLoader->GetFunction("s_ContainerTriggerDisable");
	FlushContainer = (TInterfaceFlushContainer)m_pDllLoader->GetFunction("s_FlushContainer");

    // Is functions
    IsInterfaceType = (TInterfaceIsInterfaceType)m_pDllLoader->GetFunction("s_IsInterfaceType");
    IsFirewire = (TInterfaceIsFirewire)m_pDllLoader->GetFunction("s_IsFirewire");
    IsSerial = (TInterfaceIsSerial)m_pDllLoader->GetFunction("s_IsSerial");
    IsTransferingProfiles = (TInterfaceIsTransferingProfiles)m_pDllLoader->GetFunction("s_IsTransferingProfiles");

    // PartialProfile functions
    GetPartialProfileUnitSize = (TInterfaceGetPartialProfileUnitSize)m_pDllLoader->GetFunction("s_GetPartialProfileUnitSize");
    GetPartialProfile = (TInterfaceGetPartialProfile)m_pDllLoader->GetFunction("s_GetPartialProfile");
    SetPartialProfile = (TInterfaceSetPartialProfile)m_pDllLoader->GetFunction("s_SetPartialProfile");

    // Timestamp convert functions
    Timestamp2CmmTriggerAndInCounter = (TInterfaceTimestamp2CmmTriggerAndInCounter)m_pDllLoader->GetFunction("s_Timestamp2CmmTriggerAndInCounter");
    Timestamp2TimeAndCount = (TInterfaceTimestamp2TimeAndCount)m_pDllLoader->GetFunction("s_Timestamp2TimeAndCount");

    // PostProcessing functions
    ReadPostProcessingParameter = (TInterfaceReadPostProcessingParameter)m_pDllLoader->GetFunction("s_ReadPostProcessingParameter");
    WritePostProcessingParameter = (TInterfaceWritePostProcessingParameter)m_pDllLoader->GetFunction("s_WritePostProcessingParameter");
    ConvertProfile2ModuleResult = (TInterfaceConvertProfile2ModuleResult)m_pDllLoader->GetFunction("s_ConvertProfile2ModuleResult");

    // Load/Save functions
    LoadProfiles = (TInterfaceLoadProfiles)m_pDllLoader->GetFunction("s_LoadProfiles");
    SaveProfiles = (TInterfaceSaveProfiles)m_pDllLoader->GetFunction("s_SaveProfiles");
    LoadProfilesGetPos = (TInterfaceLoadProfilesGetPos)m_pDllLoader->GetFunction("s_LoadProfilesGetPos");
    LoadProfilesSetPos = (TInterfaceLoadProfilesSetPos)m_pDllLoader->GetFunction("s_LoadProfilesSetPos");

    // Special CMM trigger functions
    StartTransmissionAndCmmTrigger = (TInterfaceStartTransmissionAndCmmTrigger)m_pDllLoader->GetFunction("s_StartTransmissionAndCmmTrigger");
    StopTransmissionAndCmmTrigger = (TInterfaceStopTransmissionAndCmmTrigger)m_pDllLoader->GetFunction("s_StopTransmissionAndCmmTrigger");

    // Converts a error-value in a string
    TranslateErrorValue = (TInterfaceTranslateErrorValue)m_pDllLoader->GetFunction("s_TranslateErrorValue");

    // User mode
    GetActualUserMode = (TInterfaceGetActualUserMode)m_pDllLoader->GetFunction("s_GetActualUserMode");
    ReadWriteUserModes = (TInterfaceReadWriteUserModes)m_pDllLoader->GetFunction("s_ReadWriteUserModes");
    SaveGlobalParameter = (TInterfaceSaveGlobalParameter)m_pDllLoader->GetFunction("s_SaveGlobalParameter");


}

const char * CInterfaceLLT::CFunctions::getDllVersion()
{
    return m_dll_version;
}

/*
 * functions for writing to sequectial register of sensor (EXTRA parameter / Sharpness)
 */

// Write command for sequenciell register
int CInterfaceLLT::write_command(unsigned int command, unsigned int data, unsigned int *toggle)
{
    int ret = SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, (unsigned int)(command << 9) + (*toggle << 8) + data);
    if (*toggle == 1) {
        *toggle = 0;
    } else {
        *toggle = 1;
    }
    return ret;
}

CInterfaceLLT &CInterfaceLLT::getInstance()
{
    static CInterfaceLLT singleton;
    return singleton;
}

const char * CInterfaceLLT::getDllVersion()
{
    return m_pFunctions->getDllVersion();
}

// Write value in sequenciell register
int CInterfaceLLT::write_value(unsigned short value, unsigned int *toggle)
{
    int ret = 0;
    if ((ret = write_command(1, (unsigned int)(value / 256), toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_command(1, (unsigned int)(value % 256), toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    return GENERAL_FUNCTION_OK;
}

// destructor of the InterfaceLLT class
// the destructor also unload the dll
CInterfaceLLT::CFunctions::~CFunctions()
{
    delete m_pDllLoader;
    Sleep(100);
    // the sleep in nessecary, because windows  needs a littel bit time to unload the dll
    // and if you unload and load the dll in a short time there were errors
}

CInterfaceLLT::CInterfaceLLT(const char *pDLLName /* = "LLT.dll"*/, bool *pLoadError /*=NULL*/)
{
    m_pLLT = NULL;
    m_pFunctions = new CFunctions(pDLLName, pLoadError);
}

CInterfaceLLT::~CInterfaceLLT()
{
    if (m_pFunctions->DelDevice)
        m_pFunctions->DelDevice(m_pLLT);

    delete m_pFunctions;
}
///////////////////////////////////////////////////////////////////////////////////////////////////
// Instance functions

int CInterfaceLLT::CreateLLTDevice(int iInterfaceType)
{
    if (m_pFunctions->CreateLLTDevice != 0) {
        m_pLLT = m_pFunctions->CreateLLTDevice(iInterfaceType);
        if (m_pLLT != 0 || m_pLLT != 0xffffffff)
            return GENERAL_FUNCTION_OK;
    }
    return GENERAL_FUNCTION_NOT_AVAILABLE;
}

int CInterfaceLLT::CreateLLTFirewire()
{
    if (m_pFunctions->CreateLLTFirewire != 0) {
        m_pLLT = m_pFunctions->CreateLLTFirewire();
        if (m_pLLT != 0 || m_pLLT != 0xffffffff)
            return GENERAL_FUNCTION_OK;
    }
    return GENERAL_FUNCTION_NOT_AVAILABLE;
}

int CInterfaceLLT::CreateLLTSerial()
{
    if (m_pFunctions->CreateLLTSerial != 0) {
        m_pLLT = m_pFunctions->CreateLLTSerial();
        if (m_pLLT != 0 || m_pLLT != 0xffffffff)
            return GENERAL_FUNCTION_OK;
    }
    return GENERAL_FUNCTION_NOT_AVAILABLE;
}

int CInterfaceLLT::GetInterfaceType()
{
    if (m_pFunctions->GetInterfaceType != 0)
        return m_pFunctions->GetInterfaceType(m_pLLT);

    return GENERAL_FUNCTION_NOT_AVAILABLE;
}

int CInterfaceLLT::DelDevice()
{
    return m_pFunctions->DelDevice(m_pLLT);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Connect functions

int CInterfaceLLT::Connect()
{
    return m_pFunctions->Connect(m_pLLT);
}

int CInterfaceLLT::Disconnect()
{
    return m_pFunctions->Disconnect(m_pLLT);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/// Read/Write config functions
int CInterfaceLLT::ExportLLTConfig(const char *pFileName)
{
    return m_pFunctions->ExportLLTConfig(m_pLLT, pFileName);
}

int CInterfaceLLT::ExportLLTConfigString(char *configData, int configDataSize)
{
    return m_pFunctions->ExportLLTConfigString(m_pLLT, configData, configDataSize);
}

int CInterfaceLLT::ImportLLTConfig(const char *pFileName, bool ignoreCalibration)
{
    return m_pFunctions->ImportLLTConfig(m_pLLT, pFileName, ignoreCalibration);
}

int CInterfaceLLT::ImportLLTConfigString(const char *configData, int configDataSize, bool ignoreCalibration)
{
    return m_pFunctions->ImportLLTConfigString(m_pLLT, configData, configDataSize, ignoreCalibration);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/// Device interface functions

int CInterfaceLLT::GetDeviceInterfacesFast(unsigned int *pInterfaces, unsigned int nSize)
{
    return m_pFunctions->GetDeviceInterfacesFast(m_pLLT, pInterfaces, nSize);
}

int CInterfaceLLT::SetDeviceInterface(unsigned int nInterface)
{
    return m_pFunctions->SetDeviceInterface(m_pLLT, nInterface, 0);
}

unsigned CInterfaceLLT::GetDiscoveryBroadcastTarget()
{
    if (m_pFunctions->GetDiscoveryBroadcastTarget != 0) {
        return m_pFunctions->GetDiscoveryBroadcastTarget(m_pLLT);
    }
    return 0;
}

int CInterfaceLLT::SetDiscoveryBroadcastTarget(unsigned int nNetworkAddress, unsigned int nSubnetMask)
{
    if (m_pFunctions->SetDiscoveryBroadcastTarget != 0) {
        return m_pFunctions->SetDiscoveryBroadcastTarget(m_pLLT, nNetworkAddress, nSubnetMask);
    }
    return GENERAL_FUNCTION_NOT_AVAILABLE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// LLT indentification functions

int CInterfaceLLT::GetDeviceName(char *pDevName, unsigned int nDevNameSize, char *pVenName, unsigned int nVenNameSize)
{
    return m_pFunctions->GetDeviceName(m_pLLT, pDevName, nDevNameSize, pVenName, nVenNameSize);
}

int CInterfaceLLT::GetSerialNumber(char *pSerialNumber, unsigned int nSerialNumberSize)
{
    return m_pFunctions->GetSerialNumber(m_pLLT, pSerialNumber, nSerialNumberSize);
}

int CInterfaceLLT::GetLLTVersions(unsigned int *pDSP, unsigned int *pFPGA1, unsigned int *pFPGA2)
{
    return m_pFunctions->GetLLTVersions(m_pLLT, pDSP, pFPGA1, pFPGA2);
}

int CInterfaceLLT::GetLLTType(TScannerType *pScannerType) { return m_pFunctions->GetLLTType(m_pLLT, pScannerType); }
///////////////////////////////////////////////////////////////////////////////////////////////////
// Get functions

int CInterfaceLLT::GetMinMaxPacketSize(unsigned long *pMinPacketSize, unsigned long *pMaxPacketSize)
{
    return m_pFunctions->GetMinMaxPacketSize(m_pLLT, pMinPacketSize, pMaxPacketSize);
}

int CInterfaceLLT::GetResolutions(unsigned int *pValue, unsigned int nSize)
{
    return m_pFunctions->GetResolutions(m_pLLT, pValue, nSize);
}

int CInterfaceLLT::GetFeature(unsigned int Function, unsigned int *pValue)
{
    return m_pFunctions->GetFeature(m_pLLT, Function, pValue);
}

int CInterfaceLLT::GetBufferCount(unsigned int *pValue)
{
    return m_pFunctions->GetBufferCount(m_pLLT, pValue);
}

int CInterfaceLLT::GetMainReflection(unsigned int *pValue)
{
    return m_pFunctions->GetMainReflection(m_pLLT, pValue);
}

int CInterfaceLLT::GetMaxFileSize(unsigned int *pValue)
{
    return m_pFunctions->GetMaxFileSize(m_pLLT, pValue);
}

int CInterfaceLLT::GetPacketSize(unsigned int *pValue)
{
    return m_pFunctions->GetPacketSize(m_pLLT, pValue);
}

int CInterfaceLLT::GetFirewireConnectionSpeed(unsigned int *pValue)
{
    return m_pFunctions->GetFirewireConnectionSpeed(m_pLLT, pValue);
}

int CInterfaceLLT::GetProfileConfig(TProfileConfig *pValue)
{
    return m_pFunctions->GetProfileConfig(m_pLLT, (int *)pValue);
}

int CInterfaceLLT::GetResolution(unsigned int *pValue)
{
    return m_pFunctions->GetResolution(m_pLLT, pValue);
}

int CInterfaceLLT::GetProfileContainerSize(unsigned int *pWidth, unsigned int *pHeight)
{
    return m_pFunctions->GetProfileContainerSize(m_pLLT, pWidth, pHeight);
}

int CInterfaceLLT::GetMaxProfileContainerSize(unsigned int *pMaxWidth, unsigned int *pMaxHeight)
{
    return m_pFunctions->GetMaxProfileContainerSize(m_pLLT, pMaxWidth, pMaxHeight);
}

int CInterfaceLLT::GetEthernetHeartbeatTimeout(unsigned int *pValue)
{
    return m_pFunctions->GetEthernetHeartbeatTimeout(m_pLLT, pValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Set functions

int CInterfaceLLT::SetFeature(unsigned int Function, unsigned int Value)
{
    return m_pFunctions->SetFeature(m_pLLT, Function, Value);
}

int
CInterfaceLLT::SetFeatureGroup(const DWORD* FeatureAddresses, const DWORD* FeatureValues,
                               DWORD FeatureCount)
{
  return m_pFunctions->SetFeatureGroup(m_pLLT, FeatureAddresses, FeatureValues, FeatureCount);
}

int CInterfaceLLT::SetBufferCount(unsigned int Value)
{
    return m_pFunctions->SetBufferCount(m_pLLT, Value);
}

int CInterfaceLLT::SetMainReflection(unsigned int Value)
{
    return m_pFunctions->SetMainReflection(m_pLLT, Value);
}

int CInterfaceLLT::SetMaxFileSize(unsigned int Value)
{
    return m_pFunctions->SetMaxFileSize(m_pLLT, Value);
}

int CInterfaceLLT::SetPacketSize(unsigned int Value)
{
    return m_pFunctions->SetPacketSize(m_pLLT, Value);
}

int CInterfaceLLT::SetFirewireConnectionSpeed(unsigned int Value)
{
    return m_pFunctions->SetFirewireConnectionSpeed(m_pLLT, Value);
}

int CInterfaceLLT::SetProfileConfig(TProfileConfig Value)
{
    return m_pFunctions->SetProfileConfig(m_pLLT, Value);
}

int CInterfaceLLT::SetResolution(unsigned int Value)
{
    return m_pFunctions->SetResolution(m_pLLT, Value);
}

int CInterfaceLLT::SetProfileContainerSize(unsigned int nWidth, unsigned int nHeight)
{
    return m_pFunctions->SetProfileContainerSize(m_pLLT, nWidth, nHeight);
}

int CInterfaceLLT::SetEthernetHeartbeatTimeout(unsigned int Value)
{
    return m_pFunctions->SetEthernetHeartbeatTimeout(m_pLLT, Value);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Register functions

int CInterfaceLLT::RegisterCallback(TCallbackType CallbackType, void *pLLTProfileCallback, void *pUserData)
{
    return m_pFunctions->RegisterCallback(m_pLLT, CallbackType, pLLTProfileCallback, pUserData);
}

int CInterfaceLLT::RegisterErrorMsg(UINT Msg, HWND hWnd, WPARAM WParam)
{
    return m_pFunctions->RegisterErrorMsg(m_pLLT, Msg, hWnd, WParam);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Profile transfer functions

int CInterfaceLLT::GetProfile() { return m_pFunctions->GetProfile(m_pLLT); }

int CInterfaceLLT::TransferProfiles(int TransferProfileType, int nEnable)
{
    return m_pFunctions->TransferProfiles(m_pLLT, TransferProfileType, nEnable);
}

int CInterfaceLLT::TransferVideoStream(int TransferVideoType, int nEnable, unsigned int *pWidth, unsigned int *pHeight)
{
    return m_pFunctions->TransferVideoStream(m_pLLT, TransferVideoType, nEnable, pWidth, pHeight);
}

int CInterfaceLLT::MultiShot(unsigned int nCount) { return m_pFunctions->MultiShot(m_pLLT, nCount); }

int CInterfaceLLT::GetActualProfile(unsigned char *pBuffer, unsigned int nBuffersize, TProfileConfig ProfileConfig,
                                    unsigned int *pLostProfiles)
{
    return m_pFunctions->GetActualProfile(m_pLLT, pBuffer, nBuffersize, ProfileConfig, pLostProfiles);
}

int CInterfaceLLT::ConvertProfile2Values(const unsigned char *pProfile, int size, unsigned int nResolution, TProfileConfig tProfileConfig,
                                         TScannerType ScannerType, unsigned int nReflection, unsigned short *pWidth,
                                         unsigned short *pMaximum, unsigned short *pThreshold, double *pX, double *pZ,
                                         unsigned int *pM0, unsigned int *pM1)
{
    return getInstance().MyConvertProfile2Values(pProfile, size, nResolution, tProfileConfig, ScannerType, nReflection, pWidth,
                                                 pMaximum, pThreshold, pX, pZ, pM0, pM1);
}

int CInterfaceLLT::ConvertPartProfile2Values(const unsigned char *pProfile, int size, TPartialProfile *pPartialProfile,
                                             TScannerType ScannerType, unsigned int nReflection, unsigned short *pWidth,
                                             unsigned short *pMaximum, unsigned short *pThreshold, double *pX,
                                             double *pZ, unsigned int *pM0, unsigned int *pM1)
{
    return getInstance().MyConvertPartProfile2Values(pProfile, size, pPartialProfile, ScannerType, nReflection, pWidth,
                                                     pMaximum, pThreshold, pX, pZ, pM0, pM1);
}

int CInterfaceLLT::MyConvertProfile2Values(const unsigned char *pProfile, int size, unsigned int nResolution, TProfileConfig tProfileConfig,
                                           TScannerType ScannerType, unsigned int nReflection, unsigned short *pWidth,
                                           unsigned short *pMaximum, unsigned short *pThreshold, double *pX, double *pZ,
                                           unsigned int *pM0, unsigned int *pM1)
{
    UNREFERENCED_PARAMETER(size);
    return m_pFunctions->ConvertProfile2Values(1, pProfile, nResolution, tProfileConfig, ScannerType, nReflection, 1, pWidth,
                                               pMaximum, pThreshold, pX, pZ, pM0, pM1);
}

int CInterfaceLLT::MyConvertPartProfile2Values(const unsigned char *pProfile, int size,
                                               TPartialProfile *pPartialProfile, TScannerType ScannerType,
                                               unsigned int nReflection, unsigned short *pWidth,
                                               unsigned short *pMaximum, unsigned short *pThreshold, double *pX,
                                               double *pZ, unsigned int *pM0, unsigned int *pM1)
{
    UNREFERENCED_PARAMETER(size);
    return m_pFunctions->ConvertPartProfile2Values(1, pProfile, pPartialProfile, ScannerType, nReflection, 1, pWidth,
                                                   pMaximum, pThreshold, pX, pZ, pM0, pM1);
}

int CInterfaceLLT::SetHoldBuffersForPolling(unsigned int uiHoldBuffersForPolling)
{
    return m_pFunctions->SetHoldBuffersForPolling(m_pLLT, uiHoldBuffersForPolling);
}

int CInterfaceLLT::GetHoldBuffersForPolling(unsigned int *puiHoldBuffersForPolling)
{
    return m_pFunctions->GetHoldBuffersForPolling(m_pLLT, puiHoldBuffersForPolling);
}

int
CInterfaceLLT::TriggerProfile()
{
  return m_pFunctions->TriggerProfile(m_pLLT);
}

int
CInterfaceLLT::TriggerContainer()
{
  return m_pFunctions->TriggerContainer(m_pLLT);
}

int
CInterfaceLLT::ContainerTriggerEnable()
{
  return m_pFunctions->ContainerTriggerEnable(m_pLLT);
}

int
CInterfaceLLT::ContainerTriggerDisable()
{
  return m_pFunctions->ContainerTriggerDisable(m_pLLT);
}

int
CInterfaceLLT::FlushContainer()
{
  return m_pFunctions->FlushContainer(m_pLLT);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Is functions

int CInterfaceLLT::IsInterfaceType(int iInterfaceType)
{
    if (m_pFunctions->IsInterfaceType) {
        return m_pFunctions->IsInterfaceType(m_pLLT, iInterfaceType);
    }
    return 0;
}

int CInterfaceLLT::IsFirewire() { return m_pFunctions->IsFirewire(m_pLLT); }

int CInterfaceLLT::IsSerial() { return m_pFunctions->IsSerial(m_pLLT); }

int CInterfaceLLT::IsTransferingProfiles() { return m_pFunctions->IsTransferingProfiles(m_pLLT); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// PartialProfile functions

int CInterfaceLLT::GetPartialProfileUnitSize(unsigned int *pUnitSizePoint, unsigned int *pUnitSizePointData)
{
    return m_pFunctions->GetPartialProfileUnitSize(m_pLLT, pUnitSizePoint, pUnitSizePointData);
}

int CInterfaceLLT::GetPartialProfile(TPartialProfile *pPartialProfile)
{
    return m_pFunctions->GetPartialProfile(m_pLLT, pPartialProfile);
}

int CInterfaceLLT::SetPartialProfile(TPartialProfile *pPartialProfile)
{
    return m_pFunctions->SetPartialProfile(m_pLLT, pPartialProfile);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Timestamp convert functions

void CInterfaceLLT::Timestamp2CmmTriggerAndInCounter(const unsigned char *pTimestamp, unsigned int *pInCounter,
                                                     int *pCmmTrigger, int *pCmmActive, unsigned int *pCmmCount)
{
    return m_pFunctions->Timestamp2CmmTriggerAndInCounter(pTimestamp, pInCounter, pCmmTrigger, pCmmActive, pCmmCount);
}

void CInterfaceLLT::MyTimestamp2TimeAndCount(const unsigned char *pTimestamp, double *pTimeShutterOpen,
                                             double *pTimeShutterClose, unsigned int *pProfileCount,
                                             unsigned short *enc)
{
    if (pTimestamp != NULL && enc != NULL) {
        // extract encoder x2 or state dig in
        *enc = (unsigned short)(pTimestamp[8] << 8 | pTimestamp[9]);
    }
    return m_pFunctions->Timestamp2TimeAndCount(pTimestamp, pTimeShutterOpen, pTimeShutterClose, pProfileCount);
}

void CInterfaceLLT::Timestamp2TimeAndCount(const unsigned char *pTimestamp, double *pTimeShutterOpen,
                                           double *pTimeShutterClose, unsigned int *pProfileCount, unsigned short *enc)
{
    return getInstance().MyTimestamp2TimeAndCount(pTimestamp, pTimeShutterOpen, pTimeShutterClose, pProfileCount, enc);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// PostProcessing functions

int CInterfaceLLT::ReadPostProcessingParameter(unsigned int *pParameter, unsigned int nSize)
{
    return m_pFunctions->ReadPostProcessingParameter(m_pLLT, pParameter, nSize);
}

int CInterfaceLLT::WritePostProcessingParameter(unsigned int *pParameter, unsigned int nSize)
{
    return m_pFunctions->WritePostProcessingParameter(m_pLLT, pParameter, nSize);
}

int CInterfaceLLT::ConvertProfile2ModuleResult(const unsigned char *pProfileBuffer, unsigned int nProfileBufferSize,
                                               unsigned char *pModuleResultBuffer, unsigned int nResultBufferSize,
                                               TPartialProfile *pPartialProfile /* = NULL*/)
{
    return m_pFunctions->ConvertProfile2ModuleResult(m_pLLT, pProfileBuffer, nProfileBufferSize, pModuleResultBuffer,
                                                     nResultBufferSize, pPartialProfile);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// File functions

int CInterfaceLLT::LoadProfiles(const char *pFilename, TPartialProfile *pPartialProfile, TProfileConfig *pProfileConfig,
                                TScannerType *pScannerType, unsigned int *pRearrengementProfile)
{
    return m_pFunctions->LoadProfiles(m_pLLT, pFilename, pPartialProfile, pProfileConfig, pScannerType,
                                      pRearrengementProfile);
}

int CInterfaceLLT::SaveProfiles(const char *pFilename, TFileType FileType)
{
    return m_pFunctions->SaveProfiles(m_pLLT, pFilename, FileType);
}

int CInterfaceLLT::LoadProfilesGetPos(unsigned int *pActualPosition, unsigned int *pMaxPosition)
{
    return m_pFunctions->LoadProfilesGetPos(m_pLLT, pActualPosition, pMaxPosition);
}

int CInterfaceLLT::LoadProfilesSetPos(unsigned int nNewPosition)
{
    return m_pFunctions->LoadProfilesSetPos(m_pLLT, nNewPosition);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Special CMM trigger functions

int CInterfaceLLT::StartTransmissionAndCmmTrigger(unsigned int nCmmTrigger, TTransferProfileType TransferProfileType,
                                                  unsigned int nProfilesForerun, const char *pFilename,
                                                  TFileType FileType, unsigned int nTimeout)
{
    return m_pFunctions->StartTransmissionAndCmmTrigger(m_pLLT, nCmmTrigger, TransferProfileType, nProfilesForerun,
                                                        pFilename, FileType, nTimeout);
}

int CInterfaceLLT::StopTransmissionAndCmmTrigger(int nCmmTriggerPolarity, unsigned int nTimeout)
{
    return m_pFunctions->StopTransmissionAndCmmTrigger(m_pLLT, nCmmTriggerPolarity, nTimeout);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Converts a error-value in a string

int CInterfaceLLT::MyTranslateErrorValue(int ErrorValue, char *pString, unsigned int nStringSize)
{
    return m_pFunctions->TranslateErrorValue(1, ErrorValue, pString, nStringSize);
}

int CInterfaceLLT::TranslateErrorValue(int ErrorValue, char *pString, unsigned int nStringSize)
{
    return getInstance().MyTranslateErrorValue(ErrorValue, pString, nStringSize);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// User Mode
int CInterfaceLLT::GetActualUserMode(unsigned int *pActualUserMode, unsigned int *pUserModeCount)
{
    return m_pFunctions->GetActualUserMode(m_pLLT, pActualUserMode, pUserModeCount);
}

int CInterfaceLLT::ReadWriteUserModes(int nWrite, unsigned int nUserMode)
{
    return m_pFunctions->ReadWriteUserModes(m_pLLT, nWrite, nUserMode);
}

int CInterfaceLLT::SaveGlobalParameter(void) { return m_pFunctions->SaveGlobalParameter(m_pLLT); }

/**
 * set_peak_filter:
 * @hllt: a LLT instance
 * @min_width: minimum evaluated width
 * @max_width: maximum evaluated width
 * @min_intensity: minimum evaluated intensity
 * @max_intensity: maximum evaluated intensity
 *
 * Sets intensity and width peak filter
 *
 * Returns: error code or success
 *
 * Since: 0.2.0
 */
int CInterfaceLLT::SetPeakFilter(unsigned short min_width, unsigned short max_width, unsigned short min_intensity,
                                 unsigned short max_intensity)
{
    int ret = 0;
    unsigned int toggle = 0;
    // Initalize serializes write process
    if ((ret = write_command(0, 0, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_command(0, 0, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    // Write function values
    if ((ret = write_value(max_width, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_value(min_width, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_value(max_intensity, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_value(min_intensity, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    // Finalize write process
    if ((ret = write_command(0, 0, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    return GENERAL_FUNCTION_OK;
}

/**
 * set_free_measuring_field:
 * @hllt: a LLT instance
 * @start_z: start Z value of measuring field
 * @size_z: Z size of measuring field
 * @start_x: start Xvalue of measuring field
 * @size_x:  size of measuring field
 *
 * Sets free measuring field, depending on matrix orientation
 *
 * Returns: error code or success
 *
 * Since: 0.2.0
 */
int CInterfaceLLT::SetFreeMeasuringField(unsigned short start_x, unsigned short size_x, unsigned short start_z,
                                         unsigned short size_z)
{
    int ret = 0;
    unsigned int toggle = 0;
    // Initalize serializes write process
    if ((ret = write_command(0, 0, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_command(0, 0, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    // Go to function specific register
    if ((ret = write_command(2, 8, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    // Write function values
    if ((ret = write_value(start_z, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_value(size_z, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_value(start_x, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    if ((ret = write_value(size_x, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    // Finalize write process
    if ((ret = write_command(0, 0, &toggle)) < GENERAL_FUNCTION_OK) {
        return ret;
    }
    return GENERAL_FUNCTION_OK;
}

int CInterfaceLLT::SetCustomCalibration(double cX, double cZ, double angle, double sX, double sZ)
{
    int ret = 0;
    unsigned int tmp = 0;

    double PI = 3.14159265;

    double scaling = 0.0;
    double offset = 0.0;

    TScannerType scanner_type;

    if ((ret = m_pFunctions->GetLLTType(m_pLLT, &scanner_type)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = GetScalingAndOffsetByType(scanner_type, &scaling, &offset)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0000)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0100)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0420)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0305)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0204)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0308)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0280)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }

    //Rotation center 1 for rotating
    double x1 = cX / scaling + 32768;
    double z1 = (cZ - offset) / scaling + 32768;

    //Rotation center 2 for translating
    double x2 = 65536 - ((cX + sX) / scaling + 32768);
    double z2 = 65536 - (((cZ + sZ) - offset) / scaling + 32768);

    double rotate_angle = -angle;
    double cosinus = cos(rotate_angle * PI / 180);
    double sinus = sin(rotate_angle * PI / 180);

    //Calculate the resulting rotation center
    double x3 = x1 + (x2 - 32768) * cosinus + (z2 - 32768) * sinus;
    double z3 = z1 + (z2 - 32768) * cosinus - (x2 - 32768) * sinus;

    double temp = 0.5;
    if (x3 < 32768)
        temp = -0.5;

    // int
    unsigned int a = (unsigned int)(x3 + temp);
    unsigned int b = (unsigned int)(z3 + 0.5);

    // Korrektur
    if (a > 65535) {
        a = 65535;
    }
    if (b > 65535) {
        b = 65535;
    }

    // Ausgabe
    // X High
    tmp = 0x300 | ((a & 0xFF00) >> 8);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    // X Low
    tmp = 0x200 | (a & 0xFF);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    // Z High
    tmp = 0x300 | ((b & 0xFF00) >> 8);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    // Z Low
    tmp = 0x200 | (b & 0xFF);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }

    a = 0;
    if (rotate_angle < 0)
        b = (unsigned int)(65536 + rotate_angle / 0.01 + 0.5);
    else
        b = (unsigned int)(rotate_angle / 0.01 + 0.5);

    // Korrektur
    if (a > 65535) {
        a = 65535;
    }
    if (b > 65535) {
        b = 65535;
    }

    // Ausgabe
    // X High
    tmp = 0x300 | ((a & 0xFF00) >> 8);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    // X Low
    tmp = 0x200 | (a & 0xFF);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    // Z High
    tmp = 0x300 | ((b & 0xFF00) >> 8);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    // Z Low
    tmp = 0x200 | (b & 0xFF);
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, tmp)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }

    // Abschluss
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0100)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }

    return GENERAL_FUNCTION_OK;
}

int CInterfaceLLT::ResetCustomCalibration()
{
    int ret = 0;

    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0000)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0100)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0420)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0300)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0200)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }
    if ((ret = m_pFunctions->SetFeature(m_pLLT, FEATURE_FUNCTION_EXTRA_PARAMETER, 0x0100)) < GENERAL_FUNCTION_OK)
    {
        return ret;
    }

    return GENERAL_FUNCTION_OK;
}

int CInterfaceLLT::GetScalingAndOffsetByType(TScannerType scanner_type, double *scaling, double *offset)
{
    double tmp_scaling = 0.0;
    double tmp_offset = 0.0;

    if (scanner_type == scanCONTROL26xx_10 || scanner_type == scanCONTROL29xx_10
    ||  scanner_type == scanCONTROL25xx_10) {
        tmp_scaling = 0.0005;
        tmp_offset = 55.0;
    } else if (scanner_type == scanCONTROL26xx_25 || scanner_type == scanCONTROL29xx_25
    ||  scanner_type == scanCONTROL25xx_25) {
        tmp_scaling = 0.001;
        tmp_offset = 65.0;
    } else if (scanner_type == scanCONTROL26xx_50 || scanner_type == scanCONTROL29xx_50
    ||  scanner_type == scanCONTROL25xx_50) {
        tmp_scaling = 0.002;
        tmp_offset = 95.0;
    } else if (scanner_type == scanCONTROL26xx_100 || scanner_type == scanCONTROL29xx_100
    ||  scanner_type == scanCONTROL25xx_100) {
        tmp_scaling = 0.005;
        tmp_offset = 250.0;
    } else if (scanner_type == scanCONTROL27xx_25) {
        tmp_scaling = 0.001;
        tmp_offset = 100.0;
    } else if (scanner_type == scanCONTROL27xx_50) {
        tmp_scaling = 0.002;
        tmp_offset = 210.0;
    } else if (scanner_type == scanCONTROL27xx_100) {
        tmp_scaling = 0.005;
        tmp_offset = 450.0;
    } else if (scanner_type >= scanCONTROL30xx_25 && scanner_type <= scanCONTROL30xx_xxx) {
        unsigned int scaling_nm;
        unsigned int offset_nm;
        if ((m_pFunctions->GetFeature(m_pLLT, FEATURE_FUNCTION_CALIBRATION_SCALE, &scaling_nm)) == GENERAL_FUNCTION_OK
         && (m_pFunctions->GetFeature(m_pLLT, FEATURE_FUNCTION_CALIBRATION_OFFSET, &offset_nm)) == GENERAL_FUNCTION_OK) {
            tmp_scaling = scaling_nm/1000000.0;
            tmp_offset = offset_nm/1000000.0;
        }
        else {
            return GENERAL_FUNCTION_DEVICE_NAME_NOT_SUPPORTED;
        }
    } else {
        return GENERAL_FUNCTION_DEVICE_NAME_NOT_SUPPORTED;
    }

    if (scaling != NULL) {
        *scaling = tmp_scaling;
    }
    if (offset != NULL) {
        *offset = tmp_offset;
    }

    return GENERAL_FUNCTION_OK;
}
