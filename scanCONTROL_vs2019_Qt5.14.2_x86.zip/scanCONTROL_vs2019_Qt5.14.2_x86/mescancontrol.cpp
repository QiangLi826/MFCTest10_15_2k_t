/*
 * scanCONTROL Developer Tool - GUI application for LLT.dll and linLLT
 *
 * MIT License
 *
 * Copyright © 2017-2019 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#include "mescancontrol.h"

// Callback function declarations
static void NewProfile(const void *data, size_t data_size, void *user_data);
#ifdef __linux__
static void ConnectionLost(void *user_data);
#endif

/**
* @brief The constructor.
*/
MEScanControl::MEScanControl()
    : m_istransmitting(false),
      m_isconnected(false),
      m_hllt(new CInterfaceLLT),
      m_callback_data(new TCallbackData),
      m_lib_version("-"),
      m_selected_index(0),
      m_reflection(0),
      m_profile_config(PROFILE),
      m_scanner_type(StandardType),
      m_external_scanner_type(scanCONTROL30xx_25),
      m_resolution(0),
      m_hdr_factor(1),
      m_is_hdr(false),
      m_issubsampling(false),
      m_ismirrored_x(true),
      m_ismirrored_z(true),
      m_saturation(0.0),
      m_current_exposure(0.0),
      m_min_z(10000.0),
      m_max_z(-10000.0),
      m_min_x(10000.0),
      m_max_x(-10000.0),
      m_old_min_x(10000.0),
      m_old_max_x(-10000.0),
      m_old_min_z(10000.0),
      m_old_max_z(-10000.0),
      m_min_x_scaling(-90.0),
      m_max_x_scaling(90.0),
      m_min_z_scaling(110.0),
      m_max_z_scaling(410.0),
      m_scaling(0.0),
      m_offset(0.0),
      m_profiles_loaded(false),
      m_previous_loaded_profile(0),
      m_import_calibration(false),
      m_video_mode(VIDEO_MODE_1),
      m_expert_mode(false),
      m_image_width(0),
      m_image_height(0)
{
    m_callback_data->profile_counter = 0;
    m_callback_data->lost_profiles = 0;
    m_callback_data->profiles_per_callback = 1;
    m_callback_data->shutter_open = 0.0;
    m_callback_data->shutter_close = 0.0;
    m_callback_data->frame_rate = 0.0;
    m_callback_data->additional_parameter = 0;
    m_callback_data->first_run = true;
    m_callback_data->new_data = false;
#ifdef _WIN32
    m_hllt->CreateLLTDevice(INTF_TYPE_ETHERNET);
    m_interfaces.resize(MAX_SCANNERS_ON_IF);

    m_lib_version = QString(m_hllt->getDllVersion());
#elif __linux__
    // Not implemented in linllt yet
    // m_lib_version = QString("%1.%2.%3").arg(LINLLT_MAJOR_VERSION).arg(LINLLT_MINOR_VERSION).arg(LINLLT_MICRO_VERSION);
#endif
}

// # HELPER FUNCTIONS AND CALLBACK #

/**
* @brief Callback executed when new data was received.
*
* @details Executed if new data has been received from the scanner.
* Copies data to buffer and evaluates timestamp to generate profile statistics.
*
* @param [in] profile_data Pointer to data buffer
* @param [in] profile_data_size Size of received data
* @param [in] user_data User data pointer specified in the register function
*
*/
void NewProfile(const void *profile_data, size_t profile_data_size, void *user_data)
{
    if (profile_data == nullptr || user_data == nullptr) {
        return;
    }

    auto *cb_data = static_cast<TCallbackData *>(user_data);
    quint32 old_profile_counter = cb_data->profile_counter;
    double old_shutter_open = cb_data->shutter_open;

    QMutexLocker(&cb_data->mutex);

    if (static_cast<quint32>(cb_data->buffer.size()) >= profile_data_size) {
        // new data received
        cb_data->new_data = true;

        // copy received data to main buffer
        memcpy(&cb_data->buffer[0], profile_data, profile_data_size);

        // convert timestamp raw data to its corresponding values
        // adjusted function from LLT.dll in InterfaceLLT_2.cpp to provide this function
        CInterfaceLLT::Timestamp2TimeAndCount(&cb_data->buffer[static_cast<qint32>(profile_data_size) - 16], &cb_data->shutter_open,
                &cb_data->shutter_close, &cb_data->profile_counter,
                &cb_data->additional_parameter);
    }

    // evaluate if there are lost profiles (ignore first run)
    if (cb_data->first_run) {
        cb_data->lost_profiles = 0;
        cb_data->first_run = false;
    } else {
        qint32 lost_profiles = cb_data->profile_counter - old_profile_counter - cb_data->profiles_per_callback;
        if (lost_profiles < 0) // profile counter overrun
            lost_profiles = lost_profiles + 0x00ffffff;
        if (lost_profiles > 0) {
            cb_data->lost_profiles += lost_profiles;
        }
        double frame_rate = 1 / ((cb_data->shutter_open - old_shutter_open) /
                                 (cb_data->profile_counter - old_profile_counter));
        if (frame_rate >= 0.0) {
            cb_data->frame_rate = frame_rate;
        }
    }
}

#ifdef __linux__
/**
* @brief Callback executed when the connection to the sensor was lost (linLLT only).
*
* @details Executed connection to sensor was lost. Resets internal states.
*
* @param [in] user_data User data pointer specified in the register function
*
*/
void ConnectionLost(void *user_data)
{
    // reset internal state and emit connection lost signal
    MEScanControl *data = reinterpret_cast<MEScanControl *>(user_data);
    data->m_istransmitting = false;
    data->m_isconnected = false;
    emit data->connectionLost();
}
#endif

/**
* @brief Converts LLT.dll/linLLT integer error code to QString.
*
* @details Converted String value is trimmend to certain size if necessary.
*
* @param [in] ret Valid return value from LLT.dll
*
*/
QString MEScanControl::evalRetVal(qint32 ret)
{
    char status_msg[200];
    if (CInterfaceLLT::TranslateErrorValue(ret, status_msg, sizeof(status_msg) / sizeof(char)) >= MAX_ERROR_MESSAGE_LENGTH) {
        return QString::fromUtf8(status_msg).left(MAX_ERROR_MESSAGE_LENGTH-11).append("...");
    } else {
        return QString::fromUtf8(status_msg);
    }
}

/**
* @brief Sets integer feature value to certain register of scanCONTROL.
*
* @details Uses a bitmask to set the requested state to the specified feature.
* state must have correct bit position within register!
*
* @param [in] feature Feature register of scanCONTROL
* @param [in] state State to set (must have correct bit position)
* @param [in] bitmask Bitmask for corresponding part of register
*
*/
void MEScanControl::setIntFeature2Sensor(quint32 feature, quint32 state, quint32 bitmask)
{
    qint32 ret = 0;
    quint32 value = 0;

    // read currently set register value to keep all other settings the same
    if ((ret = m_hllt->GetFeature(feature, &value)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // reset and then set register bits
    value &= bitmask;
    state &= ~bitmask;
    value |= state;

    // set register
    if ((ret = m_hllt->SetFeature(feature, value)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Gets integer feature value to certain register of scanCONTROL.
*
* @details Uses a bitmask to get the requested state to the specified feature.
*
* @param [in] feature Feature register of scanCONTROL
* @param [in] shift Correct shift value for certain feature
* @param [in] bitmask Bitmask for corresponding part of register
*
*/
quint32 MEScanControl::getIntFeatureFromSensor(quint32 feature, quint32 shift, quint32 bitmask)
{
    qint32 ret = 0;
    quint32 value = 0;

    // read currently set register value
    if ((ret = m_hllt->GetFeature(feature, &value)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // reset value and then shift register bits
    value &= bitmask;
    value >>= shift;

    return value;
}

/**
* @brief Sets boolean feature value to certain register of scanCONTROL.
*
* @details Uses a bitmask to set the requested state to the specified feature.
*
* @param [in] feature Feature register of scanCONTROL
* @param [in] active State to set
* @param [in] bitmask Bitmask for corresponding part of register
*
*/
void MEScanControl::setBoolFeature2Sensor(quint32 feature, bool active, quint32 bitmask)
{
    quint32 value = 0;
    qint32 ret = 0;

    // read currently set register value to keep all other settings the same
    if ((ret = m_hllt->GetFeature(feature, &value)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // set/reset register bits
    if (active) {
        value |= bitmask;
    } else {
        value &= ~bitmask;
    }
    // set register
    if ((ret = m_hllt->SetFeature(feature, value)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Gets boolean feature value to certain register of scanCONTROL.
*
* @details Uses a bitmask to get the requested state to the specified feature.
*
* @param [in] feature Feature register of scanCONTROL
* @param [in] bitmask Bitmask for corresponding part of register
*
*/
bool MEScanControl::getBoolFeatureFromSensor(quint32 feature, quint32 bitmask)
{
    qint32 ret = 0;
    quint32 value = 0;

    // read currently set register value
    if ((ret = m_hllt->GetFeature(feature, &value)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    // return state by comparing with bitmask
    return (value & bitmask) != 0;
}


QString MEScanControl::getLibVersion()
{
    return m_lib_version;
}

#ifdef __linux__
QString MEScanControl::getAravisVersion()
{
    return QString("%1.%2.%3").arg(ARAVIS_MAJOR_VERSION).arg(ARAVIS_MINOR_VERSION).arg(ARAVIS_MICRO_VERSION);
}
#endif

// # MAIN SCANCONTROL FUNCTIONS #

/**
* @brief Scans the interface for scanCONTROL sensors.
*
* @details Uses GetDeviceInterfacesFast (LLT.dll) / GetDeviceInterfaces (linLLT) for finding
* scanners on the interface. IPs, serial numbers and model types are also extracted in this
* step. For this the LLT.dll needs to have sensor connection, which in case of already connected
* sensors leads to missing information.
*
*/
void MEScanControl::scanInterface()
{
    qint32 number_devices = 0;

    QStringList found_ipaddresses;
    QStringList found_serialnumbers;
    QStringList found_types;

    // search for interfaces:
    // aravis searches for device name strings | LLT.dll for IP addresses
#ifdef __linux__
    // Reset device list
    m_found_devices.clear();
    QVector<char *> interfaces(MAX_SCANNERS_ON_IF);

    // Search for device interfaces
    number_devices = CInterfaceLLT::GetDeviceInterfaces(&interfaces[0], interfaces.size());

    // Iterate over found scanners and get basic info through aravis
    for (int i = 0; i < interfaces.size(); i++) {
        if (interfaces[i] != 0) {
            m_found_devices.append(interfaces[i]);
            found_ipaddresses.append(arv_get_device_address(i));
            found_serialnumbers.append(arv_get_device_serial_nbr(i));
            found_types.append(arv_get_device_model(i));
        }
    }
#elif _WIN32
    // reset device list
    m_interfaces.fill(0);

    // search for device interfaces
    number_devices = m_hllt->GetDeviceInterfacesFast(&m_interfaces[0], m_interfaces.size());

    // iterate over found scanners and get basic info through connecting to scanners
    for (auto intf : m_interfaces) {
        if (intf != 0) {
            QHostAddress ip(intf);
            found_ipaddresses.append(ip.toString());

            // try to connect to every found scanner
            m_hllt->SetDeviceInterface(intf);
            char name[75] = "-";
            quint32 serial = 0;
            if (m_hllt->Connect() == GENERAL_FUNCTION_OK) {
                m_hllt->GetDeviceName(name, sizeof(name)/sizeof(*name), nullptr, 0);
                m_hllt->GetFeature(FEATURE_FUNCTION_SERIAL_NUMBER, &serial);
                m_hllt->Disconnect();
            }
            found_serialnumbers.append(QString::number(serial));
            found_types.append(name);
        }
    }
#endif

    emit scanInterfaceChanged(number_devices, found_ipaddresses, found_serialnumbers, found_types);
}

void MEScanControl::setIPAddress(QString ip)
{
    qint32 ret = 0;
#ifdef _WIN32
    ret = 1;
    quint32 intf = QHostAddress(ip).toIPv4Address();
    m_selected_index = 0;
    m_interfaces[m_selected_index] = intf;
#endif
    emit ipAddressSet(ret, evalRetVal(ret));
}

/**
* @brief Connects to the scanCONTROL sensor selected beforehand.
*
* @details Connects to sensor selected via the property selected_index.
*
*/
void MEScanControl::connectSensor()
{
    qint32 ret = 0;

    // set device interface selected by property selected_index
#ifdef __linux__
    m_hllt->SetDeviceInterface(m_found_devices[m_selected_index].toUtf8().data());
#elif _WIN32
    m_hllt->SetDeviceInterface(m_interfaces[m_selected_index]);
#endif

    // connect to sensors
    if ((ret = m_hllt->Connect()) == GENERAL_FUNCTION_OK) {

        // set callback functions depending on library used
#ifdef __linux__
        m_hllt->RegisterBufferCallback(reinterpret_cast<void *>(&NewProfile), static_cast<void *>(m_callback_data.data()));
        m_hllt->RegisterControlLostCallback(reinterpret_cast<void *>(&ConnectionLost), static_cast<void *>(this));
#elif _WIN32
        m_hllt->RegisterCallback(C_DECL, reinterpret_cast<void *>(&NewProfile), static_cast<void *>(m_callback_data.data()));
        // register win event in user space (0x0400) with the current window id and context
        m_hllt->RegisterErrorMsg(0x0400, reinterpret_cast<HWND>(m_wid), reinterpret_cast<WPARAM>(this));
#endif

        m_hllt->SetProfileConfig(m_profile_config);
        m_hllt->GetLLTType(&m_scanner_type);
        unsigned int resolutions[6];
        int ret = m_hllt->GetResolutions(resolutions, 6);
        if (ret <= 6) {
            m_resolutions.clear();
            for (int i=0; i<ret; i++)
                m_resolutions << resolutions[i];
        }
        if (m_scanner_type == -1) {
            m_scanner_type = m_external_scanner_type;
            ret = GENERAL_FUNCTION_DEVICE_NAME_NOT_SUPPORTED;
        }
        m_hllt->GetScalingAndOffsetByType(m_scanner_type, &m_scaling, &m_offset);
        // sensor connected
        m_isconnected = true;

        // check if sensor is subsampling scanner (naming convention: 26x7-xxx)
        m_issubsampling = getLLTName().mid(15, 1) == "7";
        m_hdr_factor = 1;

        if (m_scanner_type >= scanCONTROL26xx_25 && m_scanner_type <= scanCONTROL26xx_xxx && !m_issubsampling) {
            m_ismirrored_x = true;
            m_ismirrored_z = false;
        } else if (m_scanner_type >= scanCONTROL30xx_25 && m_scanner_type <= scanCONTROL30xx_xxx) {
            m_ismirrored_x = false;
            m_ismirrored_z = false;
            m_hdr_factor = getIntFeatureFromSensor(FEATURE_FUNCTION_IMAGE_FEATURES, 12, 0x0001F000);
        } else {
            m_ismirrored_x = true;
            m_ismirrored_z = true;
        }
        getDisplayScaling(m_min_x_scaling, m_max_x_scaling, m_min_z_scaling, m_max_z_scaling);
    }

    emit sensorConnected(ret, evalRetVal(ret));
}

/**
* @brief Disconnects from the scanCONTROL which is currently connected.
*
* @details If transmission is active, it is stopped before disconnecting.
*
*/
void MEScanControl::disconnectSensor()
{
    // stop transfer if active
    if (m_istransmitting) {
        stopTransfer();
    }

    // disconnect
    qint32 ret = m_hllt->Disconnect();
    if (ret == GENERAL_FUNCTION_OK) {
        m_isconnected = false;
    }

    emit sensorDisconnected(ret, evalRetVal(ret));
}

/**
* @brief Start profile transfer depending on current state.
*
* @details Starts all different kinds of data transmission the scanner is able to handle.
* Which mode to start is depending on the profile config set. Buffers are also allocated in
* this function.
*
*/
void MEScanControl::startTransfer()
{
    qint32 ret = 0;    
    quint32 buffer_size = 0;

    // get scanner resolution to avoid crashes, if it was changed from the outside
    m_hllt->GetResolution(&m_resolution);

    if (m_profile_config != PARTIAL_PROFILE) {
        m_hllt->SetResolution(m_resolution); // needed for LLT.dll if user mode was changed
    }

    // default transmission mode
    TTransferProfileType transfer_type = NORMAL_TRANSFER;
    m_callback_data->profiles_per_callback = 1;
    m_callback_data->buffer.clear();

    if (m_profile_config == PROFILE) {
        // default PROFILE transmission (image size: resolution x 64 bytes)
        // set buffer size accordingly
        m_image_width = 64;
        m_image_height = m_resolution;
        buffer_size = m_image_width * m_image_height;

        // adjust buffer sizes for point information to match resolution
        m_points.reserve(m_resolution);
        m_x_value.resize(m_resolution);
        m_z_value.resize(m_resolution);
        m_intensity.resize(m_resolution);
        m_threshold.resize(m_resolution);

    } else if (m_profile_config == PARTIAL_PROFILE) {
        // PARTIAL_PROFILE transmission (image size depending on partial profile struct)
        // set buffer size to (point count x data width)
        m_image_width = m_partial_profile.nPointDataWidth;
        m_image_height = m_partial_profile.nPointCount;
        buffer_size = m_image_width * m_image_height;

        // adjust buffer sizes for point information to match point count
        m_x_value.resize(m_partial_profile.nPointCount);
        m_z_value.resize(m_partial_profile.nPointCount);
        m_intensity.resize(m_partial_profile.nPointCount);
        m_threshold.resize(m_partial_profile.nPointCount);

    } else if (m_profile_config == CONTAINER) {
        // CONTAINER transmission (image size depending on container size)
        // set buffer size to (profile count x data per profile * 2); 1 data field has 2 bytes
        m_hllt->GetProfileContainerSize(&m_image_width, &m_image_height);
        buffer_size = m_image_width * m_image_height * 2;
        m_callback_data->profiles_per_callback = m_image_height;

        // init container image
        m_container_image = QImage(m_image_width, m_image_height, QImage::Format_Grayscale8);
        m_container_image.fill(255);

        // clear, resize && init additional 8-bit buffer for container mode
        m_mono8.clear();
        m_mono8.resize(m_image_width * m_image_height);
        m_mono8.fill(255);

        // adjust transmission type for container mode
        transfer_type = NORMAL_CONTAINER_MODE;
    }

    // start transmission
    if (m_profile_config == VIDEO_IMAGE) {
        ret = m_hllt->TransferVideoStream(m_video_mode, true, &m_image_width, &m_image_height);
        buffer_size = m_image_width * m_image_height;

        // init video image
        m_video_image = QImage(m_image_width, m_image_height, QImage::Format_Grayscale8);
        m_video_image.fill(255);
    } else {
        // start stream
        ret = m_hllt->TransferProfiles(transfer_type, true);
    }

    // clear main callback buffer and resize it
    m_callback_data->buffer.resize(buffer_size);

    // ret should be equal to the size of payload data per image
    if (ret >= GENERAL_FUNCTION_OK) {
        m_istransmitting = true;
        m_callback_data->first_run = true;
    }

    emit transferStarted(ret, evalRetVal(ret));
}

/**
* @brief Stops profile transfer.
*
* @details Stops the currently running profile transmission.
*
*/
void MEScanControl::stopTransfer()
{
    qint32 ret = 0;

    // cleanup
    m_video_image.fill(255);
    m_container_image.fill(255);
    m_mono8.clear();

    // select correct tranfer type
    TTransferProfileType transfer_type = NORMAL_TRANSFER;
    if (m_profile_config == CONTAINER) {
        transfer_type = NORMAL_CONTAINER_MODE;
    }

    // stopping the tranfer (similar to starting it)
    if (m_profile_config == VIDEO_IMAGE) {
        ret = m_hllt->TransferVideoStream(m_video_mode, false, nullptr, nullptr);
    } else {
        ret = m_hllt->TransferProfiles(transfer_type, false);
    }

    if (ret >= GENERAL_FUNCTION_OK) {
        m_istransmitting = false;
    }

    emit transferStopped(ret, evalRetVal(ret));
}

/**
* @brief Updates the displayed profile data.
*
* @details Converts the raw buffer data to valid measurement values and updates all
* corresponding information. Only refreshed, if new data has arrived from the scanner.
*
* @param [in] series AbstractSeries to update
*
*/
void MEScanControl::updateProfileData(QAbstractSeries *line_series,
                                      QAbstractSeries *low_series, QAbstractSeries *normal_series, QAbstractSeries *high_series,
                                      bool is_dynamic , bool plot_line, bool plot_invalid_points, bool autoscaling)
{
    if (!low_series || !normal_series || !high_series || !(m_istransmitting || m_profiles_loaded)) {
        return;
    }

    QMutexLocker(&m_callback_data->mutex);

    // only update image if new data has arrived
    if (m_callback_data->new_data) {

        qint32 ret = 0;
        qint32 point_count = 0;

        auto *low_xyseries = dynamic_cast<QXYSeries *>(low_series);
        auto *normal_xyseries = dynamic_cast<QXYSeries *>(normal_series);
        auto *high_xyseries = dynamic_cast<QXYSeries *>(high_series);

        m_callback_data->new_data = false;

        m_saturation = 0.0;

        m_min_x = 10000.0;
        m_max_x = -10000.0;
        m_min_z = 10000.0;
        m_max_z = -10000.0;

        // convert profiles depending on data format
        if (m_profile_config == PROFILE || m_profile_config == PURE_PROFILE || m_profile_config == QUARTER_PROFILE) {
            ret = CInterfaceLLT::ConvertProfile2Values(&m_callback_data->buffer[0], m_callback_data->buffer.size(),
                    m_resolution, m_profile_config, m_scanner_type, m_reflection, nullptr, &m_intensity[0],
                    &m_threshold[0], &m_x_value[0], &m_z_value[0], nullptr, nullptr);

            point_count = m_resolution;

        } else if (m_profile_config == PARTIAL_PROFILE) {
            ret = CInterfaceLLT::ConvertPartProfile2Values(&m_callback_data->buffer[0], m_callback_data->buffer.size(),
                    &m_partial_profile, m_scanner_type, m_reflection, nullptr, &m_intensity[0],
                    &m_threshold[0], &m_x_value[0], &m_z_value[0], nullptr, nullptr);

            point_count = m_partial_profile.nPointCount;
            // filter points which are overwritten by the timestamp
            if (m_partial_profile.nPointDataWidth > 0 && m_partial_profile.nPointDataWidth <= 16) {
                point_count -= 16 / m_partial_profile.nPointDataWidth;
            }
        }

        bool has_point_data = ((ret & CONVERT_X) != 0) && ((ret & CONVERT_Z) != 0);
        bool has_saturation_data = ((ret & CONVERT_MAXIMUM) != 0) && ((ret & CONVERT_THRESHOLD) != 0);

        qint32 valid_points = 0;

        if (has_point_data) {
            if (is_dynamic && has_saturation_data) {
                QVector<QPointF> low_points;
                QVector<QPointF> high_points;

                low_points.reserve(m_resolution);
                high_points.reserve(m_resolution);

                // replace previous data
                for (qint32 i = 0; i < point_count; i++) {
                    if (plot_invalid_points || m_z_value[i] != 0.0) {
                        quint32 current_saturation = m_intensity[i] + m_threshold[i];
                        if (current_saturation > INTENSITY_THRESHOLD_LOW &&
                                current_saturation < INTENSITY_THRESHOLD_HIGH) {
                            m_points.append(QPointF(m_x_value[i], m_z_value[i]));
                        } else if (current_saturation >= INTENSITY_THRESHOLD_HIGH) {
                            high_points.append(QPointF(m_x_value[i], m_z_value[i]));
                        } else {
                            low_points.append(QPointF(m_x_value[i], m_z_value[i]));
                        }

                        // get min/max values
                        if(m_x_value[i] < m_min_x) {
                            m_min_x = m_x_value[i];
                        }
                        if(m_x_value[i] > m_max_x) {
                            m_max_x = m_x_value[i];
                        }
                        if(m_z_value[i] < m_min_z) {
                            m_min_z = m_z_value[i];
                        }
                        if(m_z_value[i] > m_max_z) {
                            m_max_z = m_z_value[i];
                        }

                        if (m_z_value[i] != 0.0) {
                            // accumulate saturation if necessary info is transmitted
                            m_saturation += m_intensity[i] + m_threshold[i];
                            valid_points++;
                        }
                    }
                }

                low_xyseries->replace(low_points);
                high_xyseries->replace(high_points);

            } else {
                // replace previous data
                for (qint32 i = 0; i < point_count; i++) {
                    if (plot_invalid_points || m_z_value[i] != 0.0) {
                        m_points.append(QPointF(m_x_value[i], m_z_value[i]));

                        // get min/max values
                        if(m_x_value[i] < m_min_x) {
                            m_min_x = m_x_value[i];
                        }
                        if(m_x_value[i] > m_max_x) {
                            m_max_x = m_x_value[i];
                        }
                        if(m_z_value[i] < m_min_z) {
                            m_min_z = m_z_value[i];
                        }
                        if(m_z_value[i] > m_max_z) {
                            m_max_z = m_z_value[i];
                        }

                        // accumulate saturation if necessary info is transmitted
                        if (has_saturation_data && m_z_value[i] != 0.0) {
                            m_saturation += m_intensity[i] + m_threshold[i];
                            valid_points++;
                        }
                    }
                }
            }
        }

        double delta_min_x = abs(m_min_x - m_old_min_x);
        double delta_max_x = abs(m_max_x - m_old_max_x);
        double delta_min_z = abs(m_min_z - m_old_min_z);
        double delta_max_z = abs(m_max_z - m_old_max_z);

        if (autoscaling &&
                (delta_min_x > AUTOSCALING_SIGNAL_THRESHOLD || delta_max_x > AUTOSCALING_SIGNAL_THRESHOLD ||
                 delta_min_z > AUTOSCALING_SIGNAL_THRESHOLD || delta_max_z > AUTOSCALING_SIGNAL_THRESHOLD)) {

            m_old_min_x = m_min_x;
            m_old_max_x = m_max_x;
            m_old_min_z = m_min_z;
            m_old_max_z = m_max_z;

            emit autoscalingThresholdExceeded(m_min_x - AUTOSCALING_SIGNAL_THRESHOLD, m_max_x + AUTOSCALING_SIGNAL_THRESHOLD,
                                              m_min_z - AUTOSCALING_SIGNAL_THRESHOLD, m_max_z + AUTOSCALING_SIGNAL_THRESHOLD);
        }

        // recalculate saturation to have percentage
        m_saturation = (m_saturation / valid_points) * 100 / 1024;
        // update current exposure time
        m_current_exposure = (m_callback_data->shutter_close - m_callback_data->shutter_open) * 1000;
        if (m_is_hdr) {
            m_current_exposure /= m_hdr_factor;
        }

        // update point data in series (draws points)
        normal_xyseries->replace(m_points);

        if (plot_line) {
            auto *normal_lineseries = dynamic_cast<QLineSeries *>(line_series);
            normal_lineseries->replace(m_points);
        }

        // fill with 0 to avoid plotting the same data twice
        m_x_value.fill(0.0);
        m_z_value.fill(0.0);
        m_intensity.fill(0);
        m_threshold.fill(0);

        // delete points, but preserve memory
        m_points.clear();
    }
}

/**
* @brief Returns QImage with VideoMode data.
*
* @param [in] series AbstractSeries to update.
*/
void MEScanControl::resetProfileData(QAbstractSeries *series)
{
    auto *xySeries = dynamic_cast<QXYSeries *>(series);
    m_points.clear();
    xySeries->replace(m_points);
}

/**
* @brief Returns QImage with VideoMode data.
*
* @details Returns the Video Image, after converting the 8-bit raw data to a QImage with corresponding format.
* Image is only refreshed, if new data has arrived from the scanner.  Handles also the correct* orientation of
* video images depending on the sensors matrix rotation.
*
*/
QImage MEScanControl::getVideoImage()
{
    QMutexLocker(&m_callback_data->mutex);

    // only update image if new data has arrived
    if (m_callback_data->new_data) {
        m_callback_data->new_data = false;

        // generate mono 8-bit QImage with correct size
        QImage video_image = QImage(static_cast<const quint8 *>(m_callback_data->buffer.constData()),
                                    m_image_width, m_image_height, QImage::Format_Grayscale8);

        // rotate image depending on matrix orientation
        if (((m_scanner_type >= scanCONTROL26xx_25 && m_scanner_type <= scanCONTROL26xx_xxx) && !m_issubsampling) || m_scanner_type == scanCONTROL30xx_200) {
            m_video_image = video_image.mirrored(true, false);
        } else if ((m_scanner_type >= scanCONTROL29xx_25 && m_scanner_type <= scanCONTROL25xx_xxx) || m_issubsampling) {
            m_video_image = video_image.mirrored(true, true);
        }
    }

    return m_video_image;
}

/**
* @brief Returns QImage with ContainerMode data.
*
* @details Returns the Container Image, after converting the 16-bit raw data to a QImage with corresponding format.
* Data must be downscaled from 16-bit, to be able to display visually interpretable data. Image is only refreshed,
* if new data has arrived from the scanner.
*
*/
QImage MEScanControl::getContainerImage()
{
    QMutexLocker(&m_callback_data->mutex);

    // only update image if new data has arrived
    if (m_callback_data->new_data) {
        m_callback_data->new_data = false;

        // iterate over received data to visualize data - resource intensive; CPU doesn't scale well with big containers
        for (qint32 i = 0; i < m_callback_data->buffer.size(); i += 2) {
            // convert 8 bit received buffer image tothe valid 16 bit data
            quint32 buffer16 = ((m_callback_data->buffer[i + 1] << 8) + m_callback_data->buffer[i]) * 10000 / 65535;
            // scale the 16 bit data down to 8 bit for displaying
            m_mono8[i / 2] = static_cast<quint8>(buffer16 * 256 / 10000);
        }

        // generate mono 8-bit QImage with correct size
        m_container_image = QImage(&m_mono8[0], m_image_width, m_image_height, QImage::Format_Grayscale8);
    }

    return m_container_image;
}

/**
* @brief Returns LLT Firmware version string.
*/
QString MEScanControl::getFirmwareVersion()
{
    QRegularExpression re("v\\d\\d.\\d\\d");
    QRegularExpressionMatch match = re.match(getDeviceName());
    if (match.hasMatch()) {
        return match.captured(0);
    }
    else return QString("unknown");
}

/**
* @brief Returns LLT Firmware Minor version string.
*/
QString MEScanControl::getFirmwareMinor()
{
    qint32 ret = 0;
    quint32 dsp = 0, fpga1 = 0, fpga2 = 0;

    if ((ret = m_hllt->GetLLTVersions(&dsp, &fpga1, &fpga2)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    return QString("%1").arg(fpga2, 4, 10, QChar('0'));
}

/**
* @brief Returns LLT Firmware Build Date string.
*/
QString MEScanControl::getFirmwareBuild()
{
    QRegularExpression re("\\s+(\\d{8}\\w{2})");
    QRegularExpressionMatch match = re.match(getDeviceName());
    if (match.hasMatch()) {
        return match.captured(1);
    }
    else return QString("-");
}

/**
* @brief Returns LLT name string.
*/
QString MEScanControl::getLLTName()
{
    return getDeviceName().left(20).simplified();
}

/**
* @brief Returns LLT option string.
*/
QString MEScanControl::getLLTOption()
{
    QRegularExpression re("\\d\\s+(.*)v");
    QRegularExpressionMatch match = re.match(getDeviceName());
    if (match.hasMatch()) {
        return match.captured(1);
    }
    else return QString("");
}

/**
* @brief Returns complete LLT device name string.
*/
QString MEScanControl::getDeviceName()
{
    qint32 ret = 0;
    char name[75];
    char ven[100];

    if ((ret = m_hllt->GetDeviceName(name, sizeof(name)/sizeof(*name),
                                     ven, sizeof(ven)/sizeof(*ven))) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    return QString::fromUtf8(name);
}

/**
* @brief Returns LLT serial number.
*/
quint32 MEScanControl::getSerialNumber()
{
    qint32 ret = 0;
    quint32 serial = 0;

    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_SERIAL_NUMBER, &serial)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    return serial;
}

/**
* @brief Returns LLT IP Address.
*/
QString MEScanControl::getIPAddress()
{
    qint32 ret = 0;
    quint32 ip = 0;

    if ((ret = m_hllt->GetFeature(0x00000024, &ip)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    return QString("%1.%2.%3.%4").arg((ip >> 24) & 0xFF).arg((ip >> 16) & 0xFF)
            .arg((ip >> 8) & 0xFF).arg(ip & 0xFF);
}

QString MEScanControl::getSubnetMask()
{
    qint32 ret = 0;
    quint32 ip = 0;

    if ((ret = m_hllt->GetFeature(0x00000034, &ip)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    return QString("%1.%2.%3.%4").arg((ip >> 24) & 0xFF).arg((ip >> 16) & 0xFF)
            .arg((ip >> 8) & 0xFF).arg(ip & 0xFF);
}

QString MEScanControl::getDefaultGateway()
{
    qint32 ret = 0;
    quint32 ip = 0;

    if ((ret = m_hllt->GetFeature(0x00000044, &ip)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    return QString("%1.%2.%3.%4").arg((ip >> 24) & 0xFF).arg((ip >> 16) & 0xFF)
            .arg((ip >> 8) & 0xFF).arg(ip & 0xFF);
}

/**
* @brief Returns LLT Mac Address.
*/
QString MEScanControl::getMacAddress()
{
    qint32 ret = 0;
    quint32 mac_high = 0;
    quint32 mac_low = 0;

    if ((ret = m_hllt->GetFeature(0x00000008, &mac_high)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    if ((ret = m_hllt->GetFeature(0x0000000C, &mac_low)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return QString("%1-%2-%3-%4-%5-%6")
            .arg((mac_high>>8)&0xFF, 2, 16, QChar('0'))
            .arg((mac_high)&0xFF, 2, 16, QChar('0'))
            .arg((mac_low>>24)&0xFF, 2, 16, QChar('0'))
            .arg((mac_low>>16)&0xFF, 2, 16, QChar('0'))
            .arg((mac_low>>8)&0xFF, 2, 16, QChar('0'))
            .arg((mac_low)&0xFF, 2, 16, QChar('0'))
            .toUpper();
}

/**
* @brief Sets profile config.
*
* @param [in] new_profile_config
*/
void MEScanControl::setProfileConfig(qint32 new_profile_config)
{
    qint32 ret = 0;
    TProfileConfig profile_config = NONE;
    if (new_profile_config <= 7) {
        profile_config = static_cast<TProfileConfig>(new_profile_config);
    }

    // Hack to take weird TProfileConfig of LLT.dll in account
    m_profile_config = profile_config;
#ifdef _WIN32
    if (profile_config != PARTIAL_PROFILE) {
        profile_config = PROFILE;
    }
#endif

    if ((ret = m_hllt->SetProfileConfig(profile_config)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Sets the partial profile size.
*
* @details Defines the image size to use for profile transmissions, based on offsets and
* size (one for data, one for points).
*
* @param [in] data_start
* @param [in] data_size
* @param [in] point_start
* @param [in] number_points
*
*/
void MEScanControl::setPartialProfile(quint32 data_start, quint32 data_size, quint32 point_start, quint32 number_points)
{
    qint32 ret = 0;

    m_partial_profile.nStartPointData = data_start;
    m_partial_profile.nPointDataWidth = data_size;
    m_partial_profile.nStartPoint = point_start;
    m_partial_profile.nPointCount = number_points;

    if ((ret = m_hllt->SetPartialProfile(&m_partial_profile)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns currently loaded user mode.
*/
quint32 MEScanControl::getUserMode()
{
    qint32 ret = 0;
    quint32 user_mode = 0;

    if ((ret = m_hllt->GetActualUserMode(&user_mode, nullptr)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return user_mode;
}

/**
* @brief Loads the specified user mode.
*
* @details Loading a user mode in Windows requires Reconnect, because otherwise
* a resolution change is not considered.
*
* @param [in] user_mode
*
*/
void MEScanControl::loadFromUserMode(quint32 user_mode)
{
    qint32 ret = m_hllt->ReadWriteUserModes(false, user_mode);
#ifdef _WIN32
    m_hllt->Disconnect();
    m_hllt->Connect();
#endif
    emit userModeLoaded(ret, evalRetVal(ret), user_mode);
}

/**
* @brief Saves the current parameters to the specified user mode.
*
* @param [in] user_mode
*
*/
void MEScanControl::saveToUserMode(quint32 user_mode) {
    // Workaround LLT.dll 3.9.0.2077 (Increase HBT for Save User Mode)
    // Read old EthernetHeartbeatTimeout
    unsigned int hbt = 0;
    m_hllt->GetEthernetHeartbeatTimeout(&hbt);
    // Set EthernetHeartbeatTimeout to temp value
    m_hllt->SetEthernetHeartbeatTimeout(5000);
    qint32 ret = m_hllt->ReadWriteUserModes(true, user_mode);
    emit userModeSaved(ret, evalRetVal(ret), user_mode);
    // Set EthernetHeartbeatTimeout to old value
    m_hllt->SetEthernetHeartbeatTimeout(hbt);
}

/**
* @brief Executes Software trigger for frame trigger container mode.
*/
void MEScanControl::softwareTriggerContainer()
{
    qint32 ret = 0;
    m_callback_data->first_run = true;
    if ((ret = m_hllt->TriggerContainer()) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Force frametrigger container mode
*/
void MEScanControl::containerTriggerEnable(bool enable)
{
    qint32 ret = 0;
    if (enable) {
        ret = m_hllt->ContainerTriggerEnable();
    } else {
        ret = m_hllt->ContainerTriggerDisable();
    }
    if (ret < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Executes Software trigger for frame trigger container mode.
*/
void MEScanControl::softwareFlushContainer()
{
    qint32 ret = 0;
    m_callback_data->first_run = true;
    if ((ret = m_hllt->FlushContainer()) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Executes Software trigger, if external triggering is active.
*/
void MEScanControl::softwareTriggerProfile() {
    qint32 ret = 0;
    m_callback_data->first_run = true;
    if ((ret = m_hllt->TriggerProfile()) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Save video image to BMP with the specified path.
*
* @param [in] path
*
*/
void MEScanControl::saveVideoImage2Bmp(const QUrl& path)
{
    bool ret = false;
    QString localPath = path.toLocalFile();

    QMutexLocker(&m_callback_data->mutex);
    ret = m_video_image.save(localPath, "BMP");

    emit videoImageSaved(ret, localPath);
}

/**
* @brief Save video image to BMP with the specified path.
*
* @param [in] path
*
*/
void MEScanControl::saveContainerImage2Png(const QUrl& path)
{
    bool ret = false;
    QString localPath = path.toLocalFile();

    QMutexLocker(&m_callback_data->mutex);
    ret = m_container_image.save(localPath, "PNG");

    emit videoImageSaved(ret, localPath);
}

void MEScanControl::getSensorInfo(QString host_ip)
{
#ifdef __linux__
    sensor_info_t sensor_info[10];
    memset(sensor_info, 0, sizeof(sensor_info));
    qint32 sensors_found = m_hllt->GetDeviceInfos(host_ip.toUtf8().constData(), sensor_info, sizeof(sensor_info) / sizeof(*sensor_info), NULL);

    QStringList sensor_names, ip_addresses, mac_addresses, serial_number;
    for (int i = 0; i < sensors_found; i++) {
        sensor_names.append(sensor_info[i].model_name);
        ip_addresses.append(QString::number(sensor_info[i].ip_address));
        mac_addresses.append(sensor_info[i].mac_address);
        serial_number.append(sensor_info[i].serial_number);
    }

    emit getDeviceInfoFinished(sensors_found, sensor_names, ip_addresses, serial_number, mac_addresses);
#endif
}

/**
* @brief Loads llt_config file from the specified path.
*
* @details Loading a llt_config file in Windows requires Reconnect, because otherwise
* a resolution change is not considered.
*
* @param [in] path
*
*/
void MEScanControl::importLLTConfig(const QUrl& path)
{
    QString localPath = path.toLocalFile();
    qint32 ret = m_hllt->ImportLLTConfig(localPath.toUtf8().constData(), !m_import_calibration);
#ifdef _WIN32
    m_hllt->Disconnect();
    m_hllt->Connect();
#endif
    emit importConfigFinished(ret, evalRetVal(ret), localPath);
}

/**
* @brief Exports llt_config file to the specified path.
*
* @param [in] path
*
*/
void MEScanControl::exportLLTConfig(const QUrl& path)
{
    QString localPath = path.toLocalFile();
    qint32 ret = m_hllt->ExportLLTConfig(localPath.toUtf8().constData());
    emit exportConfigFinished(ret, evalRetVal(ret), localPath);
}

void MEScanControl::exportPostProcessingParams(const QUrl &path)
{
    QVector<quint32>ppp(1024);
    qint32 ret = m_hllt->ReadPostProcessingParameter(ppp.data(), ppp.size());

    QString localPath = path.toLocalFile();
    QFile file(localPath);
    if (file.open(QIODevice::WriteOnly))
    {
        QTextStream stream( &file );
        for (int var = 0; var < ppp.size(); ++var) {
            quint16 ppp1 = (ppp.at(var) & 0xFFFF0000) >> 16;
            quint16 ppp2 = ppp.at(var) & 0x0000FFFF;
            QString hexvalue1 = QString("0x%1").arg(ppp1, 4, 16, QLatin1Char( '0' ));
            QString hexvalue2 = QString("0x%1").arg(ppp2, 4, 16, QLatin1Char( '0' ));
            stream << hexvalue1 << " " << hexvalue2 << endl;
        }
    }
    file.close();

    emit exportConfigFinished(ret, evalRetVal(ret), localPath);
}

void MEScanControl::saveGlobalParameters()
{
    qint32 ret = m_hllt->SaveGlobalParameter();
    emit errorSensorFeature(ret, evalRetVal(ret));
}

/**
* @brief Changes the profile AND container resolution.
*
* @param [in] resolution
*
*/
void MEScanControl::setResolution(quint32 resolution)
{
    // manually check resolution before setting just to be safe
    if (resolution < 80 || resolution > 2048 || resolution % 16 != 0) {
        emit errorSensorFeature(ERROR_SETGETFUNCTIONS_NOT_SUPPORTED_RESOLUTION,
                                evalRetVal(ERROR_SETGETFUNCTIONS_NOT_SUPPORTED_RESOLUTION));
    }

    qint32 ret = 0;

    // set profile resolution
    if ((ret = m_hllt->SetResolution(resolution)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    } else {
        m_resolution = resolution;
    }

    // set container resolution (resolution bit must be calculated first)
    quint32 container_resolution = static_cast<quint32>(floor(log(static_cast<double>(resolution)) * (1.0 / log(2.0)) + 0.5));

    setIntFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, container_resolution << 12, 0xFFFF0FFF);
}

void MEScanControl::setCompressData(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_MAINTENANCE, active, MAINTENANCE_COMPRESS_DATA);
}

/**
* @brief Returns currently set profile resolution.
*/
quint32 MEScanControl::getResolution()
{
    qint32 ret = 0;
    quint32 resolution = 0;

    if ((ret = m_hllt->GetResolution(&resolution)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return resolution;
}

bool MEScanControl::getCompressData()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_MAINTENANCE, MAINTENANCE_COMPRESS_DATA);
}

/**
* @brief Sets the Ethernet heartbeat timeout in ms.
*
* @details Timeout after which the sensors closes the GVCP-Channel, if no
* keep alive signal was received.
*
* @param [in] timeout_in_ms
*
*/
void MEScanControl::setEthernetHeartbeatTimeout(quint32 timeout_in_ms)
{
    qint32 ret = 0;

    if ((ret = m_hllt->SetEthernetHeartbeatTimeout(timeout_in_ms)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns the Ethernet heartbeat timeout in ms.
*/
quint32 MEScanControl::getEthernetHeartbeatTimeout()
{
    qint32 ret = 0;
    quint32 timeout = 0;

    if ((ret = m_hllt->GetEthernetHeartbeatTimeout(&timeout)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return timeout;
}

/**
* @brief Sets the Ethernet packet size.
*
* @param [in] packet_size
*
*/
void MEScanControl::setPacketSize(quint32 packet_size) {

    qint32 ret = 0;

    if ((ret = m_hllt->SetPacketSize(packet_size)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns the Ethernet packet size.
*/
quint32 MEScanControl::getPacketSize()
{
    qint32 ret = 0;
    quint32 packet_size = 0;

    if ((ret =  m_hllt->GetPacketSize(&packet_size)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return packet_size;
}

/**
* @brief Sets the internal receive buffer size.
*
* @details Increasing this value slightly increases memory usage, but
* decreases the chance of profile loss.
*
* @param [in] buffer_count
*
*/
void MEScanControl::setBufferCount(quint32 buffer_count) {

    qint32 ret = 0;

    if ((ret = m_hllt->SetBufferCount(buffer_count)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns the internal receive buffer size
*/
quint32 MEScanControl::getBufferCount()
{
    qint32 ret = 0;
    quint32 buffer_count = 0;

    if ((ret = m_hllt->GetBufferCount(&buffer_count)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return buffer_count;
}

#ifdef _WIN32
void MEScanControl::setMaxFileSize(quint32 max_file_size)
{
    qint32 ret = 0;

    if ((ret =  m_hllt->SetMaxFileSize(max_file_size)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}
quint32 MEScanControl::getMaxFileSize()
{
    qint32 ret = 0;
    quint32 max_file_size = 0;

    if ((ret = m_hllt->GetMaxFileSize(&max_file_size)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return max_file_size;
}
#endif

/**
* @brief Sets state of the auto exposure flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setAutoExposure(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_EXPOSURE_TIME, active, EXPOSURE_AUTOMATIC);
}

/**
* @brief Returns current state of the auto exposure flag from scanCONTROL.
*/
bool MEScanControl::getAutoExposure()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_EXPOSURE_TIME, EXPOSURE_AUTOMATIC);
}



// ###################################


/**
* @brief Sets minimum auto exposure time in ms to scanCONTROL.
*
* @param [in] exposure_min_ms
*
*/
void MEScanControl::setAutoExposureMin(double exposure_min_ms)
{
    qint32 ret = 0;
    quint32 ae_limits_register = 0;

    // read currently set auto exposure limits from scanCONTROL
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_AUTOMATIC_LIMITS, &ae_limits_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    ae_limits_register &= 0xFFFFF000;
    ae_limits_register |= (quint32(round(exposure_min_ms * 100)) & 0xFFF);
    // set new minimum Auto Exposure Limit to scanCONTROL
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXPOSURE_AUTOMATIC_LIMITS, ae_limits_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns minimum auto exposure time in ms from scanCONTROL.
*/
double MEScanControl::getAutoExposureMin()
{
    qint32 ret = 0;
    quint32 exposure_time_min = 0;

    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_AUTOMATIC_LIMITS, &exposure_time_min)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // recalculate register to corresponding value in ms
    return (exposure_time_min & 0x00000FFF) / 100.0;
}

/**
* @brief Sets maximum auto exposure time in ms to scanCONTROL.
*
* @param [in] exposure_max_ms
*
*/
void MEScanControl::setAutoExposureMax(double exposure_max_ms)
{
    qint32 ret = 0;
    quint32 ae_limits_register = 0;

    // read currently set auto exposure limits from scanCONTROL
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_AUTOMATIC_LIMITS, &ae_limits_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    ae_limits_register &= 0xFF000FFF;
    ae_limits_register |= ((quint32(round(exposure_max_ms * 100)) & 0xFFF) << 12);
    // set new maximum Auto Exposure Limit to scanCONTROL
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXPOSURE_AUTOMATIC_LIMITS, ae_limits_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns maximum auto exposure time in ms from scanCONTROL.
*/
double MEScanControl::getAutoExposureMax()
{
    qint32 ret = 0;
    quint32 exposure_time_max = 0;

    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_AUTOMATIC_LIMITS, &exposure_time_max)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // recalculate register to corresponding value in ms
    return ((exposure_time_max >> 12) & 0x00000FFF) / 100.0;
}


// ###################################



/**
* @brief Sets exposure time in ms to scanCONTROL.
*
* @details Sets exposure time and keeps profile frequency the same.
*
* @param [in] exposure_ms
*
*/
void MEScanControl::setExposureTime(double new_exposure_ms)
{
    qint32 ret = 0;
    quint32 exposure_register = 0, idle_register = 0, idle_time_us = 0, exposure_time_us = 0;

    // read currently set exposure and idle time from scanCONTROL
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_TIME, &exposure_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_IDLE_TIME, &idle_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // change idle time to keep profile frequency if possible. Otherwise keep
    // it at the minimum possible value of 40/33 µs which results in a frequency change
    quint32 new_idle_time_us = 40;
    if (m_scanner_type >= scanCONTROL30xx_25 && m_scanner_type <= scanCONTROL30xx_xxx) {
        new_idle_time_us = 33;
    }
    idle_time_us = (idle_register & 0x00000FFF) * 10;
    exposure_time_us = (exposure_register & 0x00000FFF) * 10;
    idle_time_us += (idle_register & 0x0000F000) >> 12;
    exposure_time_us += (exposure_register & 0x0000F000) >> 12;

    quint32 new_exposure_time_us = static_cast<quint32>((new_exposure_ms * 1000.0) + 0.5);

    // change exposure register value to new value while keep auto mode the same
    exposure_register = (exposure_register & 0x01000000) +
            (new_exposure_time_us / 10) + ((new_exposure_time_us % 10) << 12);

    quint32 cycle_time_us = idle_time_us + exposure_time_us;
    if (new_exposure_time_us + new_idle_time_us <= cycle_time_us)
        new_idle_time_us = cycle_time_us - new_exposure_time_us;

    idle_register = (new_idle_time_us / 10) + ((new_idle_time_us % 10) << 12);

    // set new idle time to scanCONTROL
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_IDLE_TIME, idle_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // set new exposure time to scanCONTROL
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXPOSURE_TIME, exposure_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // signal if profile frequency must change
    if ((new_exposure_time_us + new_idle_time_us) != cycle_time_us) {
        emit profileFrequencyChanged(1000000.0/(new_exposure_time_us + new_idle_time_us), true);
    }
}

/**
* @brief Returns exposure time in ms from scanCONTROL.
*/
double MEScanControl::getExposureTime()
{
    qint32 ret = 0;
    quint32 exposure_time = 0;
    double exposure_time_offset_ms = 0.0;

    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_TIME, &exposure_time)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    exposure_time_offset_ms = ((exposure_time & 0x0000F000) >> 12) / 1000.0;

    // recalculate exposure time register to corresponding value in ms
    return (exposure_time & 0x00000FFF) / 100.0 + exposure_time_offset_ms;
}

/**
* @brief Sets exposure time in ms to scanCONTROL.
*
* @details Sets exposure time and keeps profile frequency the same.
*
* @param [in] exposure_ms
*
*/
void MEScanControl::setSecondExposureTime(double new_second_exposure_ms)
{
    qint32 ret = 0;
    quint32 second_exposure_time_us = static_cast<quint32>((new_second_exposure_ms * 1000.0) + 0.5);
    quint32 second_exposure_register = (second_exposure_time_us / 10) + ((second_exposure_time_us % 10) << 12);

    // set new exposure time to scanCONTROL
    if ((ret = m_hllt->SetFeature(0xf0f00828, second_exposure_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns second exposure time in ms from scanCONTROL.
*/
double MEScanControl::getSecondExposureTime()
{
    qint32 ret = 0;
    quint32 second_exposure_time = 0;
    double second_exposure_time_offset_ms = 0.0;

    if ((ret = m_hllt->GetFeature(0xf0f00828, &second_exposure_time)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    if (m_scanner_type >= scanCONTROL30xx_25 && m_scanner_type <= scanCONTROL30xx_xxx) {
        second_exposure_time_offset_ms = ((second_exposure_time & 0x0000F000) >> 12) / 1000.0;
    }

    // recalculate exposure time register to corresponding value in ms
    return (second_exposure_time & 0x00000FFF) / 100.0 + second_exposure_time_offset_ms;
}

/**
* @brief Sets profile frequency in Hz to scanCONTROL.
*
* @details Tries to set given profile frequency. If not possibledue to
* exposure time set max. possible value
*
* @param [in] frequency
*
*/
void MEScanControl::setProfileFrequency(double frequency)
{
    qint32 ret = 0;
    bool exposure_limited = false;
    quint32 exposure_register = 0;

    // Read currently set exposure time from scanCONTROL
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_TIME, &exposure_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // calculate correct idle time according to set exposure time
    // if not possible set idle time to min. value of 40 µs / 33 µs which results
    // in a different profile frequency than desired
    quint32 new_idle_time_us = 40;
    if (m_scanner_type >= scanCONTROL30xx_25 && m_scanner_type <= scanCONTROL30xx_xxx) {
        new_idle_time_us = 33;
    }
    quint32 exposure_time_us = (exposure_register & 0x00000FFF) * 10;
    exposure_time_us += (exposure_register & 0x0000F000) >> 12;

    quint32 cycle_time_us = static_cast<quint32>((1000000.0 / frequency) + 0.5);
    if (exposure_time_us + new_idle_time_us <= cycle_time_us) {
        new_idle_time_us = cycle_time_us - exposure_time_us;
    } else {
        exposure_limited = true;
    }

    quint32 idle_register = (new_idle_time_us / 10) + ((new_idle_time_us % 10) << 12);

    // set idle time value to scanCONTROL
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_IDLE_TIME, idle_register)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    // calculate actual new profile frequency
    double new_frequency = 1000000.0 / (exposure_time_us + new_idle_time_us);
    emit profileFrequencyChanged(new_frequency, exposure_limited);
}

/**
* @brief Returns profile frequency in Hz from scanCONTROL.
*/
double MEScanControl::getProfileFrequency()
{
    qint32 ret = 0;
    quint32 idle_time = 0, idle_time_offset_us = 0, exposure_time = 0, exposure_time_offset_us = 0;

    // read exposure and idle time from scanCONTROL
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_EXPOSURE_TIME, &exposure_time)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
    if ((ret = m_hllt->GetFeature(FEATURE_FUNCTION_IDLE_TIME, &idle_time)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    idle_time_offset_us = (idle_time & 0x0000F000) >> 12;
    exposure_time_offset_us = (exposure_time & 0x0000F000) >> 12;
    idle_time &= 0x00000FFF;
    exposure_time &= 0x00000FFF;

    // Calculate resulting frequency in Hz
    return 1000000.0 / (exposure_time * 10 + exposure_time_offset_us + idle_time * 10 + idle_time_offset_us);
}

/**
* @brief Sets state of the laser to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setLaserPower(quint32 state)
{
    setIntFeature2Sensor(FEATURE_FUNCTION_LASER, state, 0xFFFFFFFC);
}

/**
* @brief Returns state of the laser from scanCONTROL.
*/
quint32 MEScanControl::getLaserPower()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_LASER, 0, ~0xFFFFFFFC);
}

/**
* @brief Sets state of the pulse mode flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setPulseMode(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_LASER, active, LASER_PULSE_MODE);
}

/**
* @brief Returns current state of the pulse mode flag from scanCONTROL.
*/
bool MEScanControl::getPulseMode()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_LASER, LASER_PULSE_MODE);
}

/**
* @brief Sets threshold value to scanCONTROL.
*
* @param [in] threshold
*
*/
void MEScanControl::setThreshold(quint32 threshold)
{
    setIntFeature2Sensor(FEATURE_FUNCTION_THRESHOLD, threshold, 0xFFFFFC00);
}

/**
* @brief Returns current threshold value from scanCONTROL.
*/
quint32 MEScanControl::getThreshold()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_THRESHOLD, 0, ~0xFFFFFC00);
}

/**
* @brief Sets state of threshold automatic flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setThresholdAutomatic(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_THRESHOLD, active, THRESHOLD_AUTOMATIC);
}

/**
* @brief Returns current state of threshold automatic flag from scanCONTROL.
*/
bool MEScanControl::getThresholdAutomatic()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_THRESHOLD, THRESHOLD_AUTOMATIC);
}

/**
* @brief Sets state of ambient light suppression flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setAmbientLightSuppression(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_THRESHOLD, active, THRESHOLD_AMBIENT_LIGHT_SUPPRESSION);
}

/**
* @brief Returns current state of ambient light suppression flag from scanCONTROL.
*/
bool MEScanControl::getAmbientLightSuppression()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_THRESHOLD, THRESHOLD_AMBIENT_LIGHT_SUPPRESSION);
}

/**
* @brief Sets state of video filter flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setVideoFilter(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_THRESHOLD, active, THRESHOLD_VIDEO_FILTER);
}

/**
* @brief Returns current state of video filter flag from scanCONTROL.
*/
bool MEScanControl::getVideoFilter()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_THRESHOLD, THRESHOLD_VIDEO_FILTER);
}

/**
* @brief Sets minimum valid reflection width (peak filter) to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] min_width
*
*/
void MEScanControl::setMinWidth(quint16 min_width)
{
    qint32 ret = 0;
    setIntFeature2Sensor(FEATURE_FUNCTION_PEAKFILTER_WIDTH, min_width, 0xFFFFFC00);
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current  minimum valid reflection width (peak filter) from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getMinWidth()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PEAKFILTER_WIDTH, 0, ~0xFFFFFC00);
}

/**
* @brief Sets maximum valid reflection width (peak filter) to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] max_width
*
*/
void MEScanControl::setMaxWidth(quint16 max_width)
{
    qint32 ret = 0;
    if (max_width > 256) {
        max_width = 256;
    }
    setIntFeature2Sensor(FEATURE_FUNCTION_PEAKFILTER_WIDTH, max_width << 16, 0xFC00FFFF);
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current  maximum valid reflection width (peak filter) from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getMaxWidth()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PEAKFILTER_WIDTH, 16, ~0xFC00FFFF);
}

/**
* @brief Sets minimum valid reflection intensity (peak filter) to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] max_intensity
*
*/
void MEScanControl::setMinIntensity(quint16 min_intensity)
{
    qint32 ret = 0;
    setIntFeature2Sensor(FEATURE_FUNCTION_PEAKFILTER_HEIGHT, min_intensity, 0xFFFFFC00);
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current  minimum valid reflection intensity (peak filter) from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getMinIntensity()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PEAKFILTER_HEIGHT, 0, ~0xFFFFFC00);
}

/**
* @brief Sets maximum valid reflection intensity (peak filter) to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] max_intensity
*
*/
void MEScanControl::setMaxIntensity(quint16 max_intensity)
{
    qint32 ret = 0;
    setIntFeature2Sensor(FEATURE_FUNCTION_PEAKFILTER_HEIGHT, max_intensity << 16, 0xFC00FFFF);
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current  maximum valid reflection intensity (peak filter) from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getMaxIntensity()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PEAKFILTER_HEIGHT, 16, ~0xFC00FFFF);
}

/**
* @brief Sets peak filters to scanCONTROL (legacy mode).
*
* @details Deprecated method of setting peak filters. Necessary for LLT.dll version <3.7 / firmware version <v43.
*
* @param [in] min_width
* @param [in] max_width
* @param [in] min_intens
* @param [in] max_intens
*
*/
void MEScanControl::setPeakFilter(quint16 min_width, quint16 max_width, quint16 min_intens, quint16 max_intens)
{
    qint32 ret = 0;
    if ((ret = m_hllt->SetPeakFilter(min_width, max_width, min_intens, max_intens)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Sets state of median filter to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setMedianFilter(quint32 state)
{
    quint32 value = FILTER_MEDIAN_DISABLED;
    switch (state) {
    case 0:
        break;
    case 1:
        value = FILTER_MEDIAN_3;
        break;
    case 2:
        value = FILTER_MEDIAN_5;
        break;
    case 3:
        value = FILTER_MEDIAN_7;
        break;
    default: break;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_PROFILE_FILTER, value, 0xFFFFFFF3);
}


/**
* @brief Returns state of median filter from scanCONTROL.
*/
quint32 MEScanControl::getMedianFilter()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PROFILE_FILTER, 2, ~0xFFFFFFF3);
}

/**
* @brief Sets state of average filter to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setAvgFilter(quint32 state)
{
    setIntFeature2Sensor(FEATURE_FUNCTION_PROFILE_FILTER, state, 0xFFFFFFFC);
}

/**
* @brief Returns state of average filter from scanCONTROL.
*/
quint32 MEScanControl::getAvgFilter()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PROFILE_FILTER, 0, ~0xFFFFFFFC);
}

/**
* @brief Sets range of resampling to scanCONTROL.
*
* @param [in] range
*
*/
void MEScanControl::setResampling(quint32 range)
{
    quint32 value = FILTER_RESAMPLE_DISABLED;
    switch (range) {
    case 0:
        break;
    case 1:
        value = FILTER_RESAMPLE_TINY;
        break;
    case 2:
        value = FILTER_RESAMPLE_VERYSMALL;
        break;
    case 3:
        value = FILTER_RESAMPLE_SMALL;
        break;
    case 4:
        value = FILTER_RESAMPLE_MEDIUM;
        break;
    case 5:
        value = FILTER_RESAMPLE_LARGE;
        break;
    case 6:
        value = FILTER_RESAMPLE_VERYLARGE;
        break;
    case 7:
        value = FILTER_RESAMPLE_HUGE;
        break;
    default: break;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_PROFILE_FILTER, value, 0xFFFFFF8F);
}

/**
* @brief Returns range of resampling from scanCONTROL.
*/
quint32 MEScanControl::getResampling()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PROFILE_FILTER, 4, ~0xFFFFFF8F);
}

/**
* @brief Sets state of interpolate invalid points flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setInterpolateInvalidPoints(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_FILTER, active, FILTER_RESAMPLE_EXTRAPOLATE_POINTS);
}

/**
* @brief Returns current state of interpolate invalid points flag from scanCONTROL.
*/
bool MEScanControl::getInterpolateInvalidPoints()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_FILTER, FILTER_RESAMPLE_EXTRAPOLATE_POINTS);
}

/**
* @brief Sets state of resample all flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setResampleAllData(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_FILTER, active, FILTER_RESAMPLE_ALL_INFO);
}

/**
* @brief Returns current state of resample all flag from scanCONTROL.
*/
bool MEScanControl::getResampleAllData()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_FILTER, FILTER_RESAMPLE_ALL_INFO);
}

/**
* @brief Sets state of encoder active flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setEncoder(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_MAINTENANCE, active, MAINTENANCE_ENCODER_ACTIVE);
}

/**
* @brief Returns current state of encoder active flag from scanCONTROL.
*/
bool MEScanControl::getEncoder()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_MAINTENANCE, MAINTENANCE_ENCODER_ACTIVE);
}

/**
* @brief Sets state of include loopback parameters flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setLoopbackParameters(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_MAINTENANCE, active, MAINTENANCE_LOOPBACK);
}

/**
* @brief Returns current state of include loopback parameters flag from scanCONTROL.
*/
bool MEScanControl::getLoopbackParameters()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_MAINTENANCE, MAINTENANCE_LOOPBACK);
}

/**
* @brief Sets state of user mode load suppression to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setSuppressUserModeLoad(quint32 state)
{
    quint32 value = MAINTENANCE_UM_LOAD_VIA_DIGIN;
    switch (state) {
    case 0:
        break;
    case 1:
        value = MAINTENANCE_UM_SUPPRESS_UNTIL_REBOOT;
        break;
    case 2:
        value = MAINTENANCE_UM_SUPPRESS_UNTIL_GVCP_CLOSE;
        break;
    case 3:
        value = MAINTENANCE_UM_SUPPRESS_UNTIL_REBOOT_GVCP_CLOSE;
        break;
    default: break;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_MAINTENANCE, value, 0xFFFFFF3F);
}

/**
* @brief Returns state of user mode load suppression from scanCONTROL.
*/
quint32 MEScanControl::getSuppressUserModeLoad()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_MAINTENANCE, 6, ~0xFFFFFF3F);
}

/**
* @brief Sets state of rs422 mode to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setRS422Function(quint32 state)
{

    setIntFeature2Sensor(FEATURE_FUNCTION_DIGITAL_IO, state, 0xFFFFFFF0);
}

/**
* @brief Returns state of rs422 mode from scanCONTROL.
*/
quint32 MEScanControl::getRS422Function()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_DIGITAL_IO, 0, ~0xFFFFFFF0);
}

/**
* @brief Sets state of digital input mode to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setDigitalInputFunction(quint32 state)
{
    quint32 value = MULTI_DIGIN_ENC_INDEX;
    switch (state) {
    case 0:
        break;
    case 1:
        value = MULTI_DIGIN_ENC_TRIG;
        break;
    case 2:
        value = MULTI_DIGIN_TRIG_ONLY;
        break;
    case 3:
        value = MULTI_DIGIN_TRIG_UM;
        break;
    case 4:
        value = MULTI_DIGIN_UM;
        break;
    case 5:
        value = MULTI_DIGIN_TS;
        break;
    case 6:
        value = MULTI_DIGIN_FRAMETRIG_BI;
        break;
    case 7:
        value = MULTI_DIGIN_FRAMETRIG_UNI;
        break;
    case 8:
        value = MULTI_DIGIN_GATED_ENCODER;
        break;
    case 9:
        value = MULTI_DIGIN_TRIG_UM2_TS1;
        break;
    case 10:
        value = MULTI_DIGIN_UM3_TS1;
        break;
    case 11:
        value = MULTI_DIGIN_UM2_TS2;
        break;
    default: break;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_DIGITAL_IO, value, 0xFFFFFF0F);
}

/**
* @brief Returns state of digital input mode from scanCONTROL.
*/
quint32 MEScanControl::getDigitalInputFunction()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_DIGITAL_IO, 4, ~0xFFFFFF0F);
}

/**
* @brief Sets state of encoder behaviour flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setEncoderBehaviour(quint32 state)
{
    qint32 enc = MULTI_ENCODER_BIDIRECT;
    if (state == 1) {
        enc = MULTI_ENCODER_UNIDIRECT;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_DIGITAL_IO, enc, ~MULTI_ENCODER_UNIDIRECT);
}

/**
* @brief Returns current state of encoder behaviour flag from scanCONTROL.
*/
quint32 MEScanControl::getEncoderBehaviour()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_DIGITAL_IO, 9, MULTI_ENCODER_UNIDIRECT);
}

/**
* @brief Sets state of rs422 termination flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setRS422Termination(bool active)
{
    qint32 enc = MULTI_RS422_TERM_ON;
    if (!active) {
        enc = MULTI_RS422_TERM_OFF;
    }
    setIntFeature2Sensor(FEATURE_FUNCTION_DIGITAL_IO, enc, ~MULTI_RS422_TERM_OFF);
}

/**
* @brief Returns state of rs422 termination from scanCONTROL.
*/
quint32 MEScanControl::getRS422Termination()
{
    return !getIntFeatureFromSensor(FEATURE_FUNCTION_DIGITAL_IO, 10, MULTI_RS422_TERM_OFF);
}

/**
* @brief Sets state of digital input logic level to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setLogicLevel(quint32 state)
{
    // using int as input instead of boolean enables easier usage with ComboBox
    quint32 level = MULTI_LEVEL_5V;
    if (state == 1) {
        level = MULTI_LEVEL_24V;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_DIGITAL_IO, level, ~MULTI_LEVEL_24V);
}

/**
* @brief Returns state of digital input logic level from scanCONTROL.
*/
quint32 MEScanControl::getLogicLevel()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_DIGITAL_IO, 11, MULTI_LEVEL_24V);
}

/**
* @brief Sets state of digital input resistor to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setInputResistor(quint32 state)
{
    // using int as input instead of boolean enables easier usage with ComboBox
    quint32 resistor = MULTI_INPUT_PULLUP;
    if (state == 1) {
        resistor = MULTI_INPUT_PULLDOWN;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_DIGITAL_IO, resistor, ~MULTI_INPUT_PULLDOWN);
}

/**
* @brief Returns state of digital input resistor from scanCONTROL.
*/
quint32 MEScanControl::getInputResistor()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_DIGITAL_IO, 8, MULTI_INPUT_PULLDOWN);
}

/**
* @brief Sets state of reflection processing to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setReflectionProcessing(quint32 state)
{
    quint32 value = PROC_MULTIREFL_ALL;
    switch (state) {
    case 0:
        break;
    case 1:
        value = PROC_MULITREFL_FIRST;
        break;
    case 2:
        value = PROC_MULITREFL_LAST;
        break;
    case 3:
        value = PROC_MULITREFL_LARGESTAREA;
        break;
    case 4:
        value = PROC_MULITREFL_MAXINTENS;
        break;
    case 5:
        value = PROC_MULITREFL_SINGLE;
        break;
    default:
        return;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, value, 0xFFFFFFE3);
}

/**
* @brief Returns state of reflection processing from scanCONTROL.
*/
quint32 MEScanControl::getReflectionProcessing()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, 2, ~0xFFFFFFE3);
}

/**
* @brief Sets state of high resolution flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setHighResolution(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, active, PROC_HIGH_RESOLUTION);
}

/**
* @brief Returns current state of high resolution flag from scanCONTROL.
*/
bool MEScanControl::getHighResolution()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_HIGH_RESOLUTION);
}

/**
* @brief Sets state of post processing flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setPostProcessing(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, active, PROC_POSTPROCESSING_ON);
}

/**
* @brief Returns current state of post processing flag from scanCONTROL.
*/
bool MEScanControl::getPostProcessing()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_POSTPROCESSING_ON);
}

/**
* @brief Sets state of flip position flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setFlipPosition(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, active, PROC_FLIP_POSITION);
}

/**
* @brief Returns current state of flip position flag from scanCONTROL.
*/
bool MEScanControl::getFlipPosition()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_FLIP_POSITION);
}

/**
* @brief Sets state of flip distance flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setFlipDistance(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, active, PROC_FLIP_DISTANCE);
}

/**
* @brief Returns current state of flip distance flag from scanCONTROL.
*/
bool MEScanControl::getFlipDistance()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_FLIP_DISTANCE);
}

/**
* @brief Sets state of calibration flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setCalibration(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, active, PROC_CALIBRATION);
}

/**
* @brief Returns current state of calibration flag from scanCONTROL.
*/
bool MEScanControl::getCalibration()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_CALIBRATION);
}

/**
* @brief Sets state of exposure alignment to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setExposureAlignment(quint32 state)
{
    quint32 value = PROC_SHUTTERALIGN_CENTER;
    switch (state) {
    case 0:
        break;
    case 1:
        value = PROC_SHUTTERALIGN_RIGHT;
        break;
    case 2:
        value = PROC_SHUTTERALIGN_LEFT;
        break;
    case 3:
        value = PROC_SHUTTERALIGN_OFF;
        break;
    default:
        return;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, value, 0xFFFFF9FF);
}

/**
* @brief Returns current state of shutter alignment from scanCONTROL.
*/
quint32 MEScanControl::getExposureAlignment()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, 9, ~0xFFFFF9FF);
}

/**
* @brief Sets auto shutter algorithm to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setAutoExposureAlgo(quint32 state)
{
    bool adv = false;
    bool delay = false;
    switch (state) {
    case 0:
        adv = true;
        break;
    case 1:
        break;
    case 2:
        delay = true;
        break;
    default:
        return;
    }

    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, adv, PROC_AUTOSHUTTER_ADVANCED);
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_PROCESSING, delay, PROC_AUTOSHUTTER_DELAY);
}

/**
* @brief Returns current state of auto shutter algorithm from scanCONTROL.
*/
quint32 MEScanControl::getAutoExposureAlgo()
{
    bool adv = getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_AUTOSHUTTER_ADVANCED);
    bool delay = getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_PROCESSING, PROC_AUTOSHUTTER_DELAY);

    if (adv) {
        return 0;
    } else if (!delay) {
        return 1;
    } else {
        return 2;
    }
}

/**
* @brief Sets trigger mode to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setTriggerMode(quint32 index)
{
    quint32 trigger = 0;
    quint32 mask = 0;

    m_callback_data->lost_profiles = 0;
    m_callback_data->first_run = true;

    // Set value if internal
    if (index == 0) {
        mask = ~TRIG_EXT_ACTIVE;
    } else {
        // reset trigger mode and polarity bits and activate external trigger
        mask = 0xFCF0FFFF;
        trigger |= TRIG_EXT_ACTIVE;

        switch (index) {
        case 1:
            trigger |= TRIG_MODE_EDGE | TRIG_POLARITY_HIGH;
            break;
        case 2:
            trigger |= TRIG_MODE_EDGE | TRIG_POLARITY_LOW;
            break;
        case 3:
            trigger |= TRIG_MODE_PULSE | TRIG_POLARITY_HIGH;
            break;
        case 4:
            trigger |= TRIG_MODE_PULSE | TRIG_POLARITY_LOW;
            break;
        case 5:
            trigger |= TRIG_MODE_GATE | TRIG_POLARITY_HIGH;
            break;
        case 6:
            trigger |= TRIG_MODE_GATE | TRIG_POLARITY_LOW;
            break;
        case 7:
            trigger |= TRIG_MODE_ENCODER | TRIG_POLARITY_HIGH;
            break;
        case 8:
            trigger |= TRIG_MODE_ENCODER | TRIG_POLARITY_LOW;
            break;
        default:
            break;
        }
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_TRIGGER, trigger, mask);
}

/**
* @brief Returns current state of trigger mode from scanCONTROL.
*/
quint32 MEScanControl::getTriggerMode()
{
    quint32 trig_mode = getIntFeatureFromSensor(FEATURE_FUNCTION_TRIGGER, 16, ~0xFFF0FFFF);
    bool ext_trig = getBoolFeatureFromSensor(FEATURE_FUNCTION_TRIGGER, TRIG_EXT_ACTIVE);
    bool polarity_high = getBoolFeatureFromSensor(FEATURE_FUNCTION_TRIGGER, TRIG_POLARITY_HIGH);

    quint32 index = 0;

    if (ext_trig) {
        switch (trig_mode) {
        case 0:
            index = 1;
            break;
        case 1:
            index = 3;
            break;
        case 2:
            index = 5;
            break;
        case 3:
            index = 7;
            break;
        default:
            break;
        }
        if (!polarity_high) {
            index++;
        }
    }
    return index;
}

/**
* @brief Sets trigger input source to scanCONTROL.
*
* @param [in] state
*
*/
void MEScanControl::setTriggerInput(quint32 state)
{
    // reset profile statistics
    m_callback_data->lost_profiles = 0;
    m_callback_data->first_run = true;

    qint32 input = TRIG_INPUT_RS422;
    if (state == 1) {
        input = TRIG_INPUT_DIGIN;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_TRIGGER, input, ~TRIG_INPUT_DIGIN);
}

/**
* @brief Returns current state of trigger input source from scanCONTROL.
*/
quint32 MEScanControl::getTriggerInput()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_TRIGGER, 21, TRIG_INPUT_DIGIN);
}

/**
* @brief Sets encoder divider to scanCONTROL.
*
* @param [in] divider
*
*/
void MEScanControl::setEncoderDivider(quint32 divider)
{
    setIntFeature2Sensor(FEATURE_FUNCTION_TRIGGER, divider, 0xFFFFF000);
}

/**
* @brief Returns current value of encoder divider from scanCONTROL.
*/
quint32 MEScanControl::getEncoderDivider()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_TRIGGER, 0, ~0xFFFFF000);
}

void MEScanControl::setRoi1Preset(quint32 number)
{
    setIntFeature2Sensor(FEATURE_FUNCTION_ROI1_PRESET, number, 0xFFFFF800);
}

/**
* @brief Returns currently set ROI1 preset from scanCONTROL.
*/
quint32 MEScanControl::getRoi1Preset()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_ROI1_PRESET, 0, ~0xFFFFF800);
}

/**
* @brief Sets ROI1 free region bit to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setRoi1FreeRegion(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_ROI1_PRESET, active, ROI1_FREE_REGION);
}

/**
* @brief Returns state of ROI1 free region bit from scanCONTROL.
*/
bool MEScanControl::getRoi1FreeRegion()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_ROI1_PRESET, ROI1_FREE_REGION);
}

/**
* @brief Sets position (X) start of ROI1 region to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] x_start
*
*/
void MEScanControl::setRoi1StartX(quint16 x_start)
{
    qint32 ret = 0;

    setFieldStart(x_start, FEATURE_FUNCTION_ROI1_POSITION, m_ismirrored_x);
    // activate set value
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current position (X) start of ROI1 region from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getRoi1StartX()
{
    return getFieldStart(FEATURE_FUNCTION_ROI1_POSITION, m_ismirrored_x);
}

/**
* @brief Sets position (X) end of ROI1 region to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] x_end
*
*/
void MEScanControl::setRoi1EndX(quint16 x_end)
{
    qint32 ret = 0;

    setFieldEnd(x_end, FEATURE_FUNCTION_ROI1_POSITION, m_ismirrored_x);
    // activate set value
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current position (X) end of ROI1 region from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getRoi1EndX()
{
    return getFieldEnd(FEATURE_FUNCTION_ROI1_POSITION, m_ismirrored_x);
}

/**
* @brief Sets distance (Z) start of ROI1 region to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] z_start
*
*/
void MEScanControl::setRoi1StartZ(quint16 z_start)
{
    qint32 ret = 0;

    setFieldStart(z_start, FEATURE_FUNCTION_ROI1_DISTANCE, m_ismirrored_z);
    // activate set value
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current distance (Z) start of ROI1 region from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getRoi1StartZ()
{
    return getFieldStart(FEATURE_FUNCTION_ROI1_DISTANCE, m_ismirrored_z);
}

/**
* @brief Sets distance (Z) end of ROI1 region to scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*
* @param [in] z_end
*
*/
void MEScanControl::setRoi1EndZ(quint16 z_end)
{
    qint32 ret = 0;

    setFieldEnd(z_end, FEATURE_FUNCTION_ROI1_DISTANCE, m_ismirrored_z);
    // activate set value
    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_EXTRA_PARAMETER, 0)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns current distance (Z) end of ROI1 region from scanCONTROL.
*
* @details Only possible with DLL version >3.7 and LLT firmware >v43!
*/
quint16 MEScanControl::getRoi1EndZ()
{
    return getFieldEnd(FEATURE_FUNCTION_ROI1_DISTANCE, m_ismirrored_z);
}

void MEScanControl::setFieldStart(quint16 start, quint32 feature, bool mirrored)
{ 
    quint16 size = 0;

    // recalculate rows according to matrix rotation
    if (mirrored) {
        // size_new = 2^16-1 - start' - start
        size = 65535 - start - getIntFeatureFromSensor(feature, 16, ~0x0000FFFF);
    }
    else {
        size = getFieldEnd(feature, false) - start;
        setIntFeature2Sensor(feature, start << 16, 0x0000FFFF);
    }
    setIntFeature2Sensor(feature, size, 0xFFFF0000);
}

quint16 MEScanControl::getFieldStart(quint32 feature, bool mirrored)
{
    if (mirrored) {
        quint32 size = getIntFeatureFromSensor(feature, 0, ~0xFFFF0000);
        quint32 start = getIntFeatureFromSensor(feature, 16, ~0x0000FFFF);
        return 65535 - (start + size);
    }
    else return getIntFeatureFromSensor(feature, 16, ~0x0000FFFF);
}

void MEScanControl::setFieldEnd(quint16 end, quint32 feature, bool mirrored)
{
    quint16 size = 0;

    // recalculate rows according to matrix rotation
    if (mirrored) {
        // start_new = 2^16-1 - end'
        quint16 start = 65535 - end;
        // size_new = size_old + start_old - start_new
        size = getIntFeatureFromSensor(feature, 0, ~0xFFFF0000) +
                getIntFeatureFromSensor(feature, 16, ~0x0000FFFF) - start;
        setIntFeature2Sensor(feature, start << 16, 0x0000FFFF);
    }
    // size_new = end' - start
    else size = end - getIntFeatureFromSensor(feature, 16, ~0x0000FFFF);

    setIntFeature2Sensor(feature, size, 0xFFFF0000);
}

quint16 MEScanControl::getFieldEnd(quint32 feature, bool mirrored)
{
    quint16 start = getIntFeatureFromSensor(feature, 16, ~0x0000FFFF);
    if (mirrored)
        return 65535 - start;
    else {
        quint16 size = getIntFeatureFromSensor(feature, 0, ~0xFFFF0000);
        return start + size;
    }
}

/**
* @brief Sets free measuring field to scanCONTROL (legacy mode).
*
* @details Deprecated method of setting the free measuring field (ROI1). Necessary for LLT.dll version <3.7 / firmware version <v43.
*
* @param [in] column_start
* @param [in] column_end
* @param [in] row_start
* @param [in] row_end
*
*/
void MEScanControl::setFreeMeasuringField(double column_start, double column_end, double row_start, double row_end)
{
    qint32 ret = 0;
    quint32 row_s = 0;

    // recalculate column percentage values to integer values
    quint32 col_s = 65535 - (column_end / 100 * 65535);
    quint32 col_size = (column_end - column_start) / 100 * 65535;

    // recalculate row percentage values to integer values depending on matrix rotation
    if (m_scanner_type >= scanCONTROL26xx_25 && m_scanner_type <= scanCONTROL26xx_xxx && !m_issubsampling) {
        row_s = row_start / 100 * 65535;
    } else {
        row_s = 65535 - (row_end / 100 * 65535);
    }
    quint32 row_size = (row_end - row_start) / 100 * 65535;

    if ((ret = m_hllt->SetFreeMeasuringField(col_s, col_size, row_s, row_size)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

void MEScanControl::setCustomCalibration(double angle, double sX, double sZ)
{
    qint32 ret = 0;
    // set rotation center to middle of measuring range to allow readback
    if ((ret = m_hllt->SetCustomCalibration(0.0, m_offset, angle, sX, sZ)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

void MEScanControl::resetCustomCalibration()
{
    qint32 ret = 0;
    if ((ret = m_hllt->ResetCustomCalibration()) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Sets packet delay in µs to scanCONTROL.
*
* @param [in] delay_in_us
*
*/
void MEScanControl::setPacketDelay(quint32 delay_in_us)
{
    qint32 ret = 0;

    if ((ret = m_hllt->SetFeature(FEATURE_FUNCTION_PACKET_DELAY, delay_in_us)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns currently set packet delay in µs from scanCONTROL.
*/
quint32 MEScanControl::getPacketDelay()
{
    return getIntFeatureFromSensor(FEATURE_FUNCTION_PACKET_DELAY, 0, ~0xFFFF0000);
}

/**
* @brief Sets container z data flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerZ(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_Z);
}

/**
* @brief Returns state of container z data flag from scanCONTROL.
*/
bool MEScanControl::getContainerZ()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_Z);
}

/**
* @brief Sets container x data flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerX(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_X);
}

/**
* @brief Returns state of container x data flag from scanCONTROL.
*/
bool MEScanControl::getContainerX()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_X);
}

/**
* @brief Sets container threshold data flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerThreshold(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_THRES);
}

/**
* @brief Returns state of container threshold data flag from scanCONTROL.
*/
bool MEScanControl::getContainerThreshold()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_THRES);
}

/**
* @brief Sets container intensity flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerIntensity(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_INTENS);
}

/**
* @brief Returns state of container intensity flag from scanCONTROL.
*/
bool MEScanControl::getContainerIntensity()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_INTENS);
}

/**
* @brief Sets container reflection width flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerWidth(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_WIDTH);
}

/**
* @brief Returns state of container reflection width flag from scanCONTROL.
*/
bool MEScanControl::getContainerWidth()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_WIDTH);
}


/**
* @brief Sets container moment 0 flags (upper) to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerMoment0Upper(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_MOM0U);
}

/**
* @brief Sets container moment 0 flags (lower) to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerMoment0(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_MOM0L);
    //setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_MOM0U);
}

/**
* @brief Returns state of moment 0 flags rom scanCONTROL. Alternating bit state not handled
* at the moment (pun not intended :-)).
*/
bool MEScanControl::getContainerMoment0Upper()
{
    return //getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM0L) ||
            getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM0U);
}

/**
* @brief Returns state of moment 0 flags rom scanCONTROL. Alternating bit state not handled
* at the moment (pun not intended :-)).
*/
bool MEScanControl::getContainerMoment0()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM0L);// ||
           // getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM0U);
}

/**
* @brief Sets container moment 1 flags (upper) to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerMoment1Upper(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_MOM1U);
}

/**
* @brief Sets container moment 0 flags (lower) to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerMoment1(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_MOM1L);
    //setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_MOM1U);
}

/**
* @brief Returns state of container moment 1 flags from scanCONTROL. Alternating bit state not handled
* at the moment (pun not intended :-)).
*/
bool MEScanControl::getContainerMoment1Upper()
{
    return //getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM1L) ||
            getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM1U);
}

/**
* @brief Returns state of container moment 1 flags from scanCONTROL. Alternating bit state not handled
* at the moment (pun not intended :-)).
*/
bool MEScanControl::getContainerMoment1()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM1L); //||
           // getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_MOM1U);
}

/**
* @brief Sets container timestamp flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerTimestamp(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_TS);
}

/**
* @brief Returns state of container timestamp flag from scanCONTROL.
*/
bool MEScanControl::getContainerTimestamp()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_TS);
}

/**
* @brief Sets container timestamp field flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerTimestampField(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_EMPTYFIELD4TS);
}

/**
* @brief Returns state of container timestamp field flag from scanCONTROL.
*/
bool MEScanControl::getContainerTimestampField()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_EMPTYFIELD4TS);
}

/**
* @brief Sets container loopback flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerLoopback(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_LOOPBACK);
}

/**
* @brief Returns state of container loopback flag from scanCONTROL.
*/
bool MEScanControl::getContainerLoopback()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_LOOPBACK);
}

/**
* @brief Sets container data "is little endian" flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerLittleEndian(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_LSBF);
}

/**
* @brief Returns state of container data "is little endian" flag from scanCONTROL.
*/
bool MEScanControl::getContainerLittleEndian()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_LSBF);
}

/**
* @brief Sets container data signed flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerSigned(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_DATA_SIGNED);
}

/**
* @brief Returns state of container data signed flag from scanCONTROL.
*/
bool MEScanControl::getContainerSigned()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_DATA_SIGNED);
}

/**
* @brief Sets container join flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerJoin(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_JOIN);
}

/**
* @brief Returns state of container join flag from scanCONTROL.
*/
bool MEScanControl::getContainerJoin()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_JOIN);
}

/**
* @brief Sets container stripe 1 flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerStripe1(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_STRIPE_1);
}

/**
* @brief Returns state of container stripe 1 flag from scanCONTROL.
*/
bool MEScanControl::getContainerStripe1()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_STRIPE_1);
}

/**
* @brief Sets container stripe 2 flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerStripe2(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_STRIPE_2);
}

/**
* @brief Returns state of container stripe 2 flag from scanCONTROL.
*/
bool MEScanControl::getContainerStripe2()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_STRIPE_2);
}

/**
* @brief Sets container stripe 3 flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerStripe3(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_STRIPE_3);
}

/**
* @brief Returns state of container stripe 3 flag from scanCONTROL.
*/
bool MEScanControl::getContainerStripe3()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_STRIPE_3);
}

/**
* @brief Sets container stripe 4 flag to scanCONTROL.
*
* @param [in] active
*
*/
void MEScanControl::setContainerStripe4(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, active, CONTAINER_STRIPE_4);
}

/**
* @brief Returns state of container stripe 4 flag from scanCONTROL.
*/
bool MEScanControl::getContainerStripe4()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_PROFILE_REARRANGEMENT, CONTAINER_STRIPE_4);
}

/**
* @brief Sets profile per container setting to scanCONTROL.
*
* @param [in] profile_per_container Number of profiles per container to set
*
*/
void MEScanControl::setProfilesPerContainer(quint32 profile_per_container)
{
    qint32 ret = 0;

    if ((ret = m_hllt->SetProfileContainerSize(0, profile_per_container)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }
}

/**
* @brief Returns profile per container setting from scanCONTROL.
*/
quint32 MEScanControl::getProfilesPerContainer()
{
    qint32 ret = 0;
    quint32 profile_per_container = 0;

    if ((ret = m_hllt->GetProfileContainerSize(nullptr, &profile_per_container)) < GENERAL_FUNCTION_OK) {
        emit errorSensorFeature(ret, evalRetVal(ret));
    }

    return profile_per_container;
}


void MEScanControl::setCalibActive(bool active)
{
    if (active) {
        setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_0, 0x05000004, 0x00000000);
        setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_1, 0x08000080, 0x00000000);
    } else {
        setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_0, 0x00000000, 0x00000000);
        setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_1, 0x00000000, 0x00000000);
    }
}

bool MEScanControl::getCalibActive()
{
    quint32 calib_0 = getIntFeatureFromSensor(FEATURE_FUNCTION_CALIBRATION_0, 0, ~0x00000000);
    quint32 calib_1 = getIntFeatureFromSensor(FEATURE_FUNCTION_CALIBRATION_1, 0, ~0x00000000);
    return (calib_0 == 0x05000004) && (calib_1 == 0x08000080);
}

void MEScanControl::setCalibRotAngle(double angle)
{
    double rotate_angle = -angle;
    quint32 angle_reg_value = 0;

    double sX = getCalibTranslateX();
    // invert sZ to have correct behaviour while flip distance active (default case)
    double sZ = -getCalibTranslateZ();

    if (rotate_angle < 0)
        angle_reg_value = static_cast<quint32>(65536 + rotate_angle / 0.01 + 0.5);
    else
        angle_reg_value = static_cast<quint32>(rotate_angle / 0.01 + 0.5);

    // correction
    if (angle_reg_value > 65535) {
        angle_reg_value = 65535;
    }

    setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_3, angle_reg_value, 0xFFFF0000);

    // X value must be set manually again, as Z is not updated according to new angle yet
    angle = -angle * PI / 180;
    double x = -1 / m_scaling * (-32768 * m_scaling + sX * cos(angle) + sZ * sin(angle));
    double z = 1 / m_scaling * (32768 * m_scaling - sZ * cos(angle) + sX * sin(angle));

    // correct rounding errors
    if (x < 32768) {
        x -= -0.5;
    } else {
        x += 0.5;
    }
    z += 0.5;

    quint16 register_val_x = static_cast<quint16>(x);
    quint16 register_val_z = static_cast<quint16>(z);

    quint32 register_value = (register_val_x << 16) + register_val_z;

    setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_2, register_value, 0x00000000);

    setCalibTranslateZ(-sZ);
}

double MEScanControl::getCalibRotAngle()
{
    qint32 angle_reg_value = static_cast<qint32>(getIntFeatureFromSensor(FEATURE_FUNCTION_CALIBRATION_3, 0, ~0xFFFF0000));

    double angle = 0.0;
    if (angle_reg_value <= 18000) {
        angle = -((angle_reg_value - 0.5) * 0.01);
    } else if (angle_reg_value >= 47536) {
        angle = -((angle_reg_value - 65536 - 0.5) * 0.01);
    }

    return angle;
}

void MEScanControl::setCalibTranslateX(double sX)
{
    // invert sZ to have correct behaviour while flip distance active (default case)
    double sZ = -getCalibTranslateZ();

    double angle = -getCalibRotAngle() * PI / 180;
    double x = -1 / m_scaling * (-32768 * m_scaling + sX * cos(angle) + sZ * sin(angle));
    double z = 1 / m_scaling * (32768 * m_scaling - sZ * cos(angle) + sX * sin(angle));

    // correct rounding errors
    if (x < 32768) {
        x -= -0.5;
    } else {
        x += 0.5;
    }
    z += 0.5;

    quint16 register_val_x = static_cast<quint16>(x);
    quint16 register_val_z = static_cast<quint16>(z);

    quint32 register_value = (register_val_x << 16) + register_val_z;

    setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_2, register_value, 0x00000000);
}

double MEScanControl::getCalibTranslateX()
{
    quint32 calib_register_value = getIntFeatureFromSensor(FEATURE_FUNCTION_CALIBRATION_2, 0, ~0x00000000);

    quint16 x = (calib_register_value & 0xFFFF0000) >> 16;
    quint16 z = calib_register_value & 0x0000FFFF;

    double angle = -getCalibRotAngle() * PI / 180;

    double translate_x = m_scaling * sin(angle) * ((-x + 32768) / tan(angle) + z - 32768);

    return translate_x;
}

void MEScanControl::setCalibTranslateZ(double sZ)
{
    double sX = getCalibTranslateX();
    double angle = -getCalibRotAngle() * PI / 180;

    // invert sZ to have correct behaviour while flip distance active (default case)
    sZ = -sZ;

    double x = -1 / m_scaling * (-32768 * m_scaling + sX * cos(angle) + sZ * sin(angle));
    double z = 1 / m_scaling * (32768 * m_scaling - sZ * cos(angle) + sX * sin(angle));

    // correct rounding errors
    if (x < 32768) {
        x -= -0.5;
    } else {
        x += 0.5;
    }
    z += 0.5;

    quint16 register_val_x = static_cast<quint16>(x);
    quint16 register_val_z = static_cast<quint16>(z);

    quint32 register_value = (register_val_x << 16) + register_val_z;

    setIntFeature2Sensor(FEATURE_FUNCTION_CALIBRATION_2, register_value, 0x00000000);
}

double MEScanControl::getCalibTranslateZ()
{
    quint32 calib_register_value = getIntFeatureFromSensor(FEATURE_FUNCTION_CALIBRATION_2, 0, ~0x00000000);

    quint16 x = (calib_register_value & 0xFFFF0000) >> 16;
    quint16 z = calib_register_value & 0x0000FFFF;

    double angle = -getCalibRotAngle() * PI / 180;

    double translate_z = -m_scaling * sin(angle) * ((z - 32768) / tan(angle) + x - 32768);

    // invert sZ to have correct behaviour while flip distance active (default case)
    return -translate_z;
}

#ifdef _WIN32
void MEScanControl::loadProfiles(const QUrl& path)
{
    if(m_isconnected) {
        disconnectSensor();
    }

    quint32 rearrangement = 0;
    quint32 buffer_size = 0;
    QString localPath = path.toLocalFile();

    qint32 ret = m_hllt->LoadProfiles(localPath.toUtf8().constData(), &m_partial_profile, &m_profile_config,
                                      &m_scanner_type, &rearrangement);

    m_callback_data->first_run = true;

    bool is_profile_transmission =  m_profile_config == PROFILE ||
                                    m_profile_config == PARTIAL_PROFILE ||
                                    m_profile_config == QUARTER_PROFILE ||
                                    m_profile_config == PURE_PROFILE;

    bool has_additional_timestamp = m_profile_config == QUARTER_PROFILE ||
                                    m_profile_config == PURE_PROFILE;

    if (is_profile_transmission) {
        m_image_width = m_partial_profile.nPointDataWidth;
        m_image_height = m_partial_profile.nPointCount;
        buffer_size = m_image_width * m_image_height;
        m_x_value.resize(m_partial_profile.nPointCount);
        m_z_value.resize(m_partial_profile.nPointCount);
        m_intensity.resize(m_partial_profile.nPointCount);
        m_threshold.resize(m_partial_profile.nPointCount);

        m_resolution = m_partial_profile.nPointCount;
        if (has_additional_timestamp) {
            buffer_size += 16;
        }

        m_callback_data->buffer.clear();
        m_callback_data->buffer.resize(buffer_size);

        m_profiles_loaded = true;
        m_previous_loaded_profile = 0;
    } else {
        ret = ERROR_LOADSAVE_WRONG_PROFILE_CONFIG;
    }

    emit profileLoaded(ret, evalRetVal(ret), localPath);
}

void MEScanControl::saveProfiles(const QUrl &path)
{
    QString localPath = path.toLocalFile();
    qint32 ret = m_hllt->SaveProfiles(localPath.toUtf8().constData(), AVI);
    emit profileSavingStarted(ret, evalRetVal(ret), localPath);
}

void MEScanControl::stopSaving()
{
    qint32 ret = m_hllt->SaveProfiles(nullptr, LLT);
    emit profileSavingStopped(ret, evalRetVal(ret));
}

void MEScanControl::stopLoading()
{
    if (m_profiles_loaded) {
        qint32 ret = m_hllt->LoadProfiles(nullptr, nullptr, nullptr, nullptr, nullptr);
        m_profiles_loaded = false;
        emit profileLoadingStopped(ret, evalRetVal(ret));
    }
}

void MEScanControl::changeDisplayedProfile(qint32 position)
{
    if (position < 1) {
        position = 1;
    }

    quint32 old_profile_counter = m_callback_data->profile_counter;
    double old_shutter_open = m_callback_data->shutter_open;

    qint32 ret = m_hllt->LoadProfilesSetPos(position-1);
    ret = m_hllt->GetActualProfile(&m_callback_data->buffer[0], m_callback_data->buffer.size(), m_profile_config, nullptr);
    m_callback_data->new_data = true;

    // adjusted function from LLT.dll in InterfaceLLT_2.cpp to provide this function
    CInterfaceLLT::Timestamp2TimeAndCount(&m_callback_data->buffer[static_cast<qint32>(m_callback_data->buffer.size()) - 16],
            &m_callback_data->shutter_open, &m_callback_data->shutter_close, &m_callback_data->profile_counter,
            &m_callback_data->additional_parameter);

    if (m_callback_data->first_run) {
        m_callback_data->lost_profiles = 0;
        m_callback_data->first_run = false;
    } else {
        if ((position-1) - m_previous_loaded_profile == 1 && old_profile_counter < m_callback_data->profile_counter) {
            m_callback_data->lost_profiles += m_callback_data->profile_counter - old_profile_counter - 1;
            m_callback_data->frame_rate = 1 / ((m_callback_data->shutter_open - old_shutter_open) /
                                               (m_callback_data->profile_counter - old_profile_counter));
        }
    }
    m_previous_loaded_profile = position-1;

    emit loadedProfileChanged(ret, evalRetVal(ret));
}

void MEScanControl::saveProfileCsv(const QUrl &path)
{
    QString localPath = path.toLocalFile();
    qint32 ret = m_hllt->SaveProfiles(localPath.toUtf8().constData(), CSV);
    emit profileSavingAsCsvStarted(ret, evalRetVal(ret), localPath);
}

#endif
/**
* @brief Sets position (X) start of ROI2 region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] x_start
*
*/
void MEScanControl::setRoi2StartX(quint16 x_start)
{
    setFieldStart(x_start, FEATURE_FUNCTION_ROI2_POSITION, false);
}

/**
* @brief Returns current position (X) start of ROI2 region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoi2StartX()
{
    return getFieldStart(FEATURE_FUNCTION_ROI2_POSITION, false);
}

/**
* @brief Sets position (X) end of ROI2 regionto scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] x_end
*
*/
void MEScanControl::setRoi2EndX(quint16 x_end)
{
    setFieldEnd(x_end, FEATURE_FUNCTION_ROI2_POSITION, false);
}

/**
* @brief Returns current position (X) end of ROI2 region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoi2EndX()
{
    return getFieldEnd(FEATURE_FUNCTION_ROI2_POSITION, false);
}

/**
* @brief Sets distance (Z) start of ROI2 region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] z_start
*
*/
void MEScanControl::setRoi2StartZ(quint16 z_start)
{
    setFieldStart(z_start, FEATURE_FUNCTION_ROI2_DISTANCE, false);
}

/**
* @brief Returns current distance (Z) start of ROI2 region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoi2StartZ()
{
    return getFieldStart(FEATURE_FUNCTION_ROI2_DISTANCE, false);
}

/**
* @brief Sets distance (Z) end of ROI2 region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] z_end
*
*/
void MEScanControl::setRoi2EndZ(quint16 z_end)
{
    setFieldEnd(z_end, FEATURE_FUNCTION_ROI2_DISTANCE, false);
}

/**
* @brief Returns current distance (Z) end of ROI2 region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoi2EndZ()
{
    return getFieldEnd(FEATURE_FUNCTION_ROI2_DISTANCE, false);
}

/**
* @brief Sets position (X) start of RONI region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] x_start
*
*/
void MEScanControl::setRoniStartX(quint16 x_start)
{
    setFieldStart(x_start, FEATURE_FUNCTION_RONI_POSITION, false);
}

/**
* @brief Returns current position (X) start of RONI region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoniStartX()
{
    return getFieldStart(FEATURE_FUNCTION_RONI_POSITION, false);
}

/**
* @brief Sets position (X) end of RONI region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] x_end
*
*/
void MEScanControl::setRoniEndX(quint16 x_end)
{
    setFieldEnd(x_end, FEATURE_FUNCTION_RONI_POSITION, false);
}

/**
* @brief Returns current position (X) end of RONI regionfrom scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoniEndX()
{
    return getFieldEnd(FEATURE_FUNCTION_RONI_POSITION, false);
}

/**
* @brief Sets distance (Z) start of RONI region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] z_start
*
*/
void MEScanControl::setRoniStartZ(quint16 z_start)
{
    setFieldStart(z_start, FEATURE_FUNCTION_RONI_DISTANCE, false);
}

/**
* @brief Returns current distance (Z) start of RONI region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoniStartZ()
{
    return getFieldStart(FEATURE_FUNCTION_RONI_DISTANCE, false);
}

/**
* @brief Sets distance (Z) end of RONI region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] z_end
*
*/
void MEScanControl::setRoniEndZ(quint16 z_end)
{
    setFieldEnd(z_end, FEATURE_FUNCTION_RONI_DISTANCE, false);
}

/**
* @brief Returns current distance (Z) end of RONI region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getRoniEndZ()
{
    return getFieldEnd(FEATURE_FUNCTION_RONI_DISTANCE, false);
}

/**
* @brief Sets position (X) start of Exposure Automatic reference region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] x_start
*
*/
void MEScanControl::setEARefStartX(quint16 x_start)
{
    setFieldStart(x_start, FEATURE_FUNCTION_EA_REFERENCE_REGION_POSITION, false);
}

/**
* @brief Returns current position (X) start of Exposure Automatic reference region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getEARefStartX()
{
    return getFieldStart(FEATURE_FUNCTION_EA_REFERENCE_REGION_POSITION, false);
}

/**
* @brief Sets position (X) end of Exposure Automatic reference region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] x_end
*
*/
void MEScanControl::setEARefEndX(quint16 x_end)
{
    setFieldEnd(x_end, FEATURE_FUNCTION_EA_REFERENCE_REGION_POSITION, false);
}

/**
* @brief Returns current position (X) end of Exposure Automatic reference region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getEARefEndX()
{
    return getFieldEnd(FEATURE_FUNCTION_EA_REFERENCE_REGION_POSITION, false);
}

/**
* @brief Sets distance (Z) start of Exposure Automatic reference region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] z_start
*
*/
void MEScanControl::setEARefStartZ(quint16 z_start)
{
    setFieldStart(z_start, FEATURE_FUNCTION_EA_REFERENCE_REGION_DISTANCE, false);
}

/**
* @brief Returns current distance (Z) start of Exposure Automatic reference region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getEARefStartZ()
{
    return getFieldStart(FEATURE_FUNCTION_EA_REFERENCE_REGION_DISTANCE, false);
}

/**
* @brief Sets distance (Z) end of Exposure Automatic reference region to scanCONTROL.
*
* @details scanControl 30xx only!
*
* @param [in] z_end
*
*/
void MEScanControl::setEARefEndZ(quint16 z_end)
{
    setFieldEnd(z_end, FEATURE_FUNCTION_EA_REFERENCE_REGION_DISTANCE, false);
}

/**
* @brief Returns current distance (Z) end of Exposure Automatic reference region from scanCONTROL.
*
* @details scanControl 30xx only!
*/
quint16 MEScanControl::getEARefEndZ()
{
    return getFieldEnd(FEATURE_FUNCTION_EA_REFERENCE_REGION_DISTANCE, false);
}

/**
* @brief Sets state of free ROI2 Enable bit
*
* @details scanControl 30xx only!
*
* @param [in] active
*
*/
void MEScanControl::setRoi2(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, active, ROI2_ENABLE);
}

/**
* @brief Returns current state of ROI2 Enable bit
*
* @details scanControl 30xx only!
*
*/
bool MEScanControl::getRoi2()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_IMAGE_FEATURES, ROI2_ENABLE);
}

/**
* @brief Sets state of Region Of No Interest (RONI) Enable bit
*
* @details scanControl 30xx only!
*
* @param [in] active
*
*/
void MEScanControl::setRoni(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, active, RONI_ENABLE);
}

/**
* @brief Returns current state of Region Of No Interest (RONI) Enable bit
*
* @details scanControl 30xx only!
*
*/
bool MEScanControl::getRoni()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_IMAGE_FEATURES, RONI_ENABLE);
}

/**
* @brief Sets state of Automatic Exposure Reference Region Enable
*
* @details scanControl 30xx only!
*
* @param [in] active
*
*/
void MEScanControl::setEARef(bool active)
{
    setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, active, EA_REF_REGION_ENABLE);
}

/**
* @brief Returns current state of Automatic Exposure Reference Region Enable bit
*
* @details scanControl 30xx only!
*
*/
bool MEScanControl::getEARef()
{
    return getBoolFeatureFromSensor(FEATURE_FUNCTION_IMAGE_FEATURES, EA_REF_REGION_ENABLE);
}

/**
* @brief Returns current state of Image mode
*
* @details scanControl 30xx only!
*
*/
qint32 MEScanControl::getProfileMode()
{
    m_is_hdr = getBoolFeatureFromSensor(FEATURE_FUNCTION_IMAGE_FEATURES, HDR_ENABLE);
    bool is_subsampling = getBoolFeatureFromSensor(FEATURE_FUNCTION_IMAGE_FEATURES, HIGH_SPEED_MODE_ENABLE);

    if (m_is_hdr && is_subsampling) {
        if (m_expert_mode) {
            return 3;
        } else {
            setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, false, HDR_ENABLE);
            setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, false, HIGH_SPEED_MODE_ENABLE);
            emit errorSensorFeature(ERROR_GENERAL_GET_SET_ADDRESS, "Subsampling and HDR were both set - switched both off");
            return 0;
        }
    } else if (m_is_hdr && !is_subsampling) {
        return 2;
    } else if (!m_is_hdr && is_subsampling) {
        return 1;
    } else {
        return 0;
    }
}

/**
* @brief Sets state of Image mode
*
* @details scanControl 30xx only!
*
* @param [in] mode
*
*/
void MEScanControl::setProfileMode(qint32 mode)
{
    switch(mode) {
    case 0:
        setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, false, HDR_ENABLE);
        setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, false, HIGH_SPEED_MODE_ENABLE);
        m_is_hdr = false;
        break;
    case 1:
        setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, false, HDR_ENABLE);
        setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, true, HIGH_SPEED_MODE_ENABLE);
        m_is_hdr = false;
        break;
    case 2:
        setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, false, HIGH_SPEED_MODE_ENABLE);
        setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, true, HDR_ENABLE);
        m_is_hdr = true;
        break;
    case 3:
        if (m_expert_mode) {
            setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, true, HIGH_SPEED_MODE_ENABLE);
            setBoolFeature2Sensor(FEATURE_FUNCTION_IMAGE_FEATURES, true, HDR_ENABLE);
            m_is_hdr = true;
        }
        break;
    default:
        break;
    }

/**
* @brief Gets display scaling values
*
* @param [in] min_x_scaling, max_x_scaling, min_z_scaling, max_z_scaling
*
*/
}
void MEScanControl::getDisplayScaling(double &min_x_scaling, double &max_x_scaling, double &min_z_scaling, double &max_z_scaling)
{
    int series = getLLTName().mid(12,2).simplified().toInt();
    int mr = getLLTName().mid(17,3).simplified().toInt();
    switch (series) {
    case 25: case 26: case 29:
        if (mr == 10)   { min_x_scaling = -10; max_x_scaling = 10; min_z_scaling = 45; max_z_scaling = 70; }
        if (mr == 25)   { min_x_scaling = -30; max_x_scaling = 30; min_z_scaling = 40; max_z_scaling = 90; }
        if (mr == 50)   { min_x_scaling = -40; max_x_scaling = 40; min_z_scaling = 50; max_z_scaling = 140; }
        if (mr == 100)  { min_x_scaling = -90; max_x_scaling = 90; min_z_scaling = 110; max_z_scaling = 410; }
        break;
    case 27:
        if (mr == 25)   { min_x_scaling = -30; max_x_scaling = 30; min_z_scaling = 65; max_z_scaling = 135; }
        if (mr == 50)   { min_x_scaling = -40; max_x_scaling = 40; min_z_scaling = 140; max_z_scaling = 280; }
        if (mr == 100)  { min_x_scaling = -90; max_x_scaling = 90; min_z_scaling = 285; max_z_scaling = 615; }
        break;
    case 30:
        if (mr == 25)   { min_x_scaling = -30; max_x_scaling = 30; min_z_scaling = 60; max_z_scaling = 110; }
        if (mr == 50)   { min_x_scaling = -40; max_x_scaling = 40; min_z_scaling = 80; max_z_scaling = 170; }
        if (mr == 100)  { min_x_scaling = -75; max_x_scaling = 75; min_z_scaling = 180; max_z_scaling = 410; }
        if (mr == 200)  { min_x_scaling = -170; max_x_scaling = 170; min_z_scaling = 80; max_z_scaling = 560; }
        break;
    default:
        if (mr == 10)   { min_x_scaling = -10; max_x_scaling = 10; min_z_scaling = 45; max_z_scaling = 70; }
        if (mr == 25)   { min_x_scaling = -30; max_x_scaling = 30; min_z_scaling = 40; max_z_scaling = 90; }
        if (mr == 50)   { min_x_scaling = -40; max_x_scaling = 40; min_z_scaling = 50; max_z_scaling = 140; }
        if (mr == 100)  { min_x_scaling = -90; max_x_scaling = 90; min_z_scaling = 110; max_z_scaling = 410; }
        break;
    }
}
